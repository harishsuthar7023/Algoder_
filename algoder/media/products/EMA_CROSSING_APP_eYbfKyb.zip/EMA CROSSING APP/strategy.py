import json
import os
import datetime as dt
import pandas as pd
import logging
import traceback
from threading import Event, Thread
from time import sleep

from utils.str import *

def main_logic(index, interval, otm, tgt, sl, qty, lenth1, lenth2):

    trade_log_setup()
    with open(f"utils/login_data.json", "r") as f:
        Cread = json.load(f)

    fyr_id = Cread["FYERS ID"]
    apps_id = Cread["APP ID"]
    secret_keys = Cread["SECRET KEY"]
    totps = Cread["TOTP"]
    pin = Cread["PIN"]
    login(apps_id, secret_keys, fyr_id, totps, pin)

    today = str(dt.date.today())
    file1 = f"access_token{today}.txt"

    with open(f"utils/{file1}", "r") as file:
        access_token = file.read()

    fyers = fyersModel.FyersModel(client_id=f"{apps_id}-100", token=access_token, log_path="utils/")

    today = str(dt.date.today())
    LOG_FILE = f'TRADE_LOG/{str(dt.date.today())}.log'
    logging = logging_data(LOG_FILE)

    logging.info("----------------------------------------------------")
    logging.info("----------------------------------------------------")

    logging.info(f'idx {index},intrvl {interval},otm {otm},tgt {tgt},sl {sl},tgt {tgt},ema1 {lenth1},ema2 {lenth2}')

    # logging.info("")

    if index == "NIFTY":
        lot_size = 75
        index2 = "NIFTY50"
    elif index == "BANKNIFTY":
        lot_size = 30
        index2 = "NIFTYBANK"
    elif index == "FINNIFTY":
        lot_size = 65
        index2 = "FINNIFTY"
    elif index == "MIDCPNIFTY":
        lot_size = 120
        index2 = "MIDCPNIFTY"

    atm_strike = index_atm(fyers, index2)
    # print(type(atm_strike))
    total_pnl = 0
    atm = atm_strike

    download_instruments()
    download_instruments_sny()

    today = str(dt.date.today())
    data = pd.read_csv(f"utils/Data_{today}.csv")
    data2 = pd.read_csv(f"utils/Data2_{today}.csv")

    from_date = (dt.datetime.now() - dt.timedelta(days=4)).date()
    to_date = dt.datetime.now().date()

    data_fyrs = filter_data(data, lot_size, index, atm_strike, otm)
    data_sny = filter_data_sny(data2, index, lot_size)
    symbol = list(data_fyrs["Symbol ticker"])
    ltpSymbol = ltp_symbols(data, index, lot_size)

    candle_data = {}
    event = Event()
    Thread(
        target=data_downloader,
        args=(fyers, event, symbol, interval, from_date, to_date, candle_data, lenth1, lenth2)
    ).start()
    # print("data downloaded")
    sleep(1)
    ltp_data = {}
    # print("websocket start")

    def onmessage(message):
        if "symbol" in message:
            try:
                symbol = message["symbol"]
                if symbol not in ltp_data:
                    ltp_data[symbol] = {}
                required_keys = ["ltp"]
                for key in required_keys:
                    if key in message:
                        ltp_data[symbol].update({key: float(message[key])})
            except Exception as e:
                print("data...", e)


    def onerror(message):
        print("Error:", message)

    def onclose(message):
        print("Connection closed:", message)

    def onopen():
        data_type = "SymbolUpdate"
        fyers_ws.subscribe(symbols=ltpSymbol, data_type=data_type)
        fyers_ws.keep_running()

    fyers_ws = data_ws.FyersDataSocket(
        access_token=access_token,
        log_path="",
        litemode=False,
        write_to_file=False,
        reconnect=True,
        on_connect=onopen,
        on_close=onclose,
        on_error=onerror,
        on_message=onmessage,
    )
    fyers_ws.connect()
    sleep(3)
    # print("websocket connected")

    status = {
        x: {
            "traded": None,
            "price": None,
            "qty": None,
            "sl": None,
            "tsl": None,
            "tgt": None,
            "diff": None,
            "lastTrade": None
        }
        for x in symbol
    }
    logging.info(symbol)
    while True:
        sleep(1)
        if event.is_set():
            print("Something Went wrong..")
            break
        try:
            for i in symbol:
                # print(ltp_data[i])
                # if i not in candle_data or len(candle_data[i]) < 3:
                #     continue  # Skip if there is not enough data

                df = candle_data[i]
                ltp = ltp_data[i]["ltp"]
                ema1 = df.iloc[-2]["ema1"]
                ema1_1 = df.iloc[-3]["ema1"]
                ema9 = df.iloc[-2]["ema9"]
                ema9_9 = df.iloc[-3]["ema9"]

                if dt.datetime.now().minute % 3 == 0 and dt.datetime.now().second == 0 and status[list(status)[0]]["traded"] is None and status[list(status)[1]]["traded"] is None:
                    atm_strike = index_atm(fyers, index2)
                    if atm_strike != atm:
                        atm_strike = None
                        atm_strike = atm
                        symbol = []
                        newa_df = filter_data(data, lot_size, index, atm_strike, otm)
                        symbol = list(newa_df["Symbol ticker"])
                        event.set()
                        sleep(1)
                        candle_data = {}
                        event = Event()
                        Thread(
                            target=data_downloader,
                            args=(fyers, event, symbol, interval, from_date, to_date, candle_data, lenth1, lenth2)
                        ).start()
                        logging.info(f"New Strike price {symbol}")
                        while len(symbol) != len(candle_data):
                            sleep(0.5)
                            continue
                        status = {
                            x: {
                                "traded": None,
                                "price": None,
                                "qty": None,
                                "sl": None,
                                "tsl": None,
                                "tgt": None,
                                "diff": None,
                                "lastTrade": None
                            }
                            for x in symbol
                        }
                        break

                if status[i]["traded"] is None and ((status[i]["lastTrade"] is None or status[i]["lastTrade"] < dt.datetime.now()) and dt.datetime.now().time() > dt.time(9, 15) and dt.datetime.now().time() < dt.time(15, 0)):
                    if ema1 > ema9 and ema1_1 < ema9_9:
                        now = dt.datetime.now()
                        getsbl = getSymbol(data_sny, float(i[-7:-2]), i[-2:])
                        # placeOrder(api, getsbl, qty, "B")
                        status[i]["traded"] = "buy"
                        status[i]["price"] = ltp
                        status[i]["sl"] = ltp - sl
                        status[i]["qty"] = qty
                        status[i]["tgt"] = ltp + tgt
                        status[i]["tsl"] = ltp + tgt
                        logging.info("----------------------------------------------------")
                        # logging.info("")
                        logging.info(f"BUY {i} ltp:{status[i]['price']} sl-- {status[i]['sl']} tgt-- {status[i]['tgt']}")

                elif tgt != 0:
                    if status[i]["traded"] == "buy" and ltp > status[i]["tgt"]:
                        pnl = round((ltp - status[i]["price"]) * status[i]["qty"], 2)
                        now = dt.datetime.now()
                        total_pnl += pnl
                        logging.info(f"BUY tgt HIT {i} -- {ltp} --PNL {pnl} Total PnL: {total_pnl}")
                        # oid = placeOrder(fyers, i, status[i]["qty"], -1)
                        status[i]["traded"] = None
                        status[i]["price"] = None
                        status[i]["sl"] = None
                        status[i]["qty"] = None
                        status[i]["tgt"] = None
                        status[i]["lastTrade"] = dt.datetime.now() + dt.timedelta(minutes=1)

                elif sl != 0:
                    if status[i]["traded"] == "buy" and ltp < status[i]["sl"]:
                        pnl = round((ltp - status[i]["price"]) * status[i]["qty"], 2)
                        now = dt.datetime.now()
                        total_pnl += pnl  # Update total PnL
                        logging.info(f"BUY sl HIT {i} -- {ltp} -- PNL {pnl} Total PnL: {total_pnl}")
                        getsbl = getSymbol(data_sny, float(i[-7:-2]), i[-2:])
                        # placeOrder(api, getsbl, status[i]["qty"], "S")
                        status[i]["traded"] = None
                        status[i]["price"] = None
                        status[i]["sl"] = None
                        status[i]["qty"] = None
                        status[i]["tgt"] = None
                        status[i]["lastTrade"] = dt.datetime.now() + dt.timedelta(minutes=1)

                elif ema1 < ema9:
                    pnl = round((ltp - status[i]["price"]) * status[i]["qty"], 2)
                    now = dt.datetime.now()
                    total_pnl += pnl  # Update total PnL
                    logging.info(f"EMA CROSS {i} -- {ltp} -- PNL {pnl} Total PnL: {total_pnl}")
                    getsbl = getSymbol(data_sny, float(i[-7:-2]), i[-2:])
                    # placeOrder(api, getsbl, status[i]["qty"], "S")
                    status[i]["traded"] = None
                    status[i]["price"] = None
                    status[i]["sl"] = None
                    status[i]["qty"] = None
                    status[i]["tgt"] = None
                    status[i]["lastTrade"] = dt.datetime.now() + dt.timedelta(minutes=1)

        except Exception as e:
            # traceback.print_exc()
            logging.info("Somithing went wrong !")
            break

# main_logic("BANKNIFTY", 1, 1, 2, 2, 60, 2, 5)
