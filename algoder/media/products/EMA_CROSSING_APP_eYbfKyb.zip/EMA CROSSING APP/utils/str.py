from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import data_ws
import pandas as pd
# from utils.fyersLogin import *
# from utils.app_helper import *
# from app3 import *
import json
from urllib.parse import parse_qs,urlparse
import sys,os,pyotp
from pyotp import TOTP
import requests as rq
from time import sleep, time
# from utils.str import *
# from utils.fyersLogin import *
import datetime as dt
import pandas_ta as ta
import pickle, logging
from concurrent.futures import ThreadPoolExecutor as TRD
from threading import Thread, Event
import pdb
import traceback
# import talib as tas
from datetime import datetime ,timedelta

def trade_log_setup():
    folder_path = 'TRADE_LOG'
    current_date = datetime.now()
    seven_days_ago = current_date - timedelta(days=7)
    files = os.listdir(folder_path)
    for file in files:
        file_path = os.path.join(folder_path, file)
        # Agar file ka naam .log se end hota hai
        if file.endswith('.log'):
            try:
                # File ka date extract karo (format: YYYY-MM-DD)
                file_date = datetime.strptime(file[:10], '%Y-%m-%d')

                # Agar file ka date 7 din se purana hai, toh file delete kar do
                if file_date < seven_days_ago:
                    os.remove(file_path)
                    print(f"File deleted: {file}")
            except ValueError:
                print(f"Invalid file format: {file}")

# def logging_data(LOG_FILE):
#     logging.basicConfig(
#         format="%(asctime)s %(message)s",
#         datefmt="%H:%M:%S",
#         level=logging.INFO,
#         handlers=[logging.FileHandler(LOG_FILE, "a"), logging.StreamHandler()],
#     )
#     logger = logging.getLogger()
#     logger.setLevel(logging.INFO)
#     return logger


def logging_data(LOG_FILE):
    """Custom logger function that prevents unwanted logs."""
    # Pehle se existing handlers remove karna (jo extra logging print kar rahe hain)
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)

    # Ensure log directory exists
    os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

    # Custom logging setup
    logging.basicConfig(
        format="%(asctime)s %(message)s",
        datefmt="%H:%M:%S",
        level=logging.INFO,
        handlers=[logging.FileHandler(LOG_FILE, "a"), logging.StreamHandler()],
    )

    # ⚠️ Fyers SDK ka internal logging completely disable karna
    logging.getLogger("fyers").setLevel(logging.CRITICAL)  # Sirf critical errors allow
    logging.getLogger().setLevel(logging.CRITICAL)  # Root logger ka level bhi CRITICAL

    # Custom logger return karna
    logger = logging.getLogger("custom_logger")
    logger.setLevel(logging.INFO)

    return logger

def download_instruments():
    today = str(dt.date.today())
    filename = f"Data_{today}.csv"

    if filename not in os.listdir("utils"):
        for i in os.listdir("utils"):
            if i.startswith("Data_") and i.endswith(".csv") and i != filename:
                os.remove(f"utils/{i}")
                # print(f"File Deleted: {i}")

    if filename not in os.listdir("utils"):
        names = (
            "Fytoken",
            "Symbol Details",
            "Exchange Instrument type",
            "Minimum lot size",
            "Tick size",
            "ISIN",
            "Trading Session",
            "Last update date",
            "Expiry date",
            "Symbol ticker",
            "Exchange",
            "Segment",
            "Scrip code",
            "Underlying symbol",
            "Underlying scrip code",
            "Strike price",
            "Option type",
            "Underlying FyToken",
            "Reserved column",
            "Reserved column",
            "Reserved column",)

        print("Data Downloading..")

        for i in os.listdir("utils"):
            if filename.startswith('Data_') and filename.endswith('.csv'):
                os.remove(f"utils/{i}")
                print("File Deleted")
            fileUrl = "https://public.fyers.in/sym_details/NSE_FO.csv"
            inst = pd.read_csv(fileUrl)
            inst.columns = names
            inst.to_csv(f"utils/{filename}")
            # print("File Downloaded")
            break
    else:
        print("")




def download_instruments_sny():
    today = str(dt.date.today())
    filename = f"Data2_{today}.csv"

    if filename not in os.listdir("utils"):
        for i in os.listdir("utils"):
            if i.startswith("Data2") and i.endswith(".csv") and i != filename:
                os.remove(f"utils/{i}")
                print(f"File Deleted: {i}")

    if filename not in os.listdir("utils"):
        print("Data Downloading..")

        # Data ko download karna aur file mein save karna
        fileUrl = "https://api.shoonya.com/NFO_symbols.txt.zip"
        inst = pd.read_csv(fileUrl)
        inst.to_csv(f"utils/{filename}")
        # print("Data Downloaded")
    else:
        print("")



def ltp_symbols(df, index, lot_size):
    df = df[df["Minimum lot size"] == lot_size].copy()
    df = df[df["Underlying symbol"] == index]
    df["Expiry date"] = df["Expiry date"].apply(
        lambda x: dt.datetime.fromtimestamp(int(x)).date()
    )
    expiry = min(df["Expiry date"].unique())
    df = df[df["Expiry date"] == expiry]
    ltp_sym = df["Symbol ticker"].to_list()
    return ltp_sym


# def filter_data(df, lot_size, index, atm_strike):
#     # Filter minimum lot size aur underlying symbol ke basis par
#     df = df[df["Minimum lot size"] == lot_size].copy()
#     df = df[df["Underlying symbol"] == index]
#     df["Expiry date"] = df["Expiry date"].apply(
#         lambda x: dt.datetime.fromtimestamp(int(x)).date()
#     )

#     # Sabse kareeb expiry date ko find karna aur uske basis par filter karna
#     expiry = min(df["Expiry date"].unique())
#     df = df[df["Expiry date"] == expiry]

#     # Unnamed: 0 column ko drop karna (agar exist karta ho)
#     if "Unnamed: 0" in df.columns:
#         df = df.drop("Unnamed: 0", axis=1)

#     # ATM strike ke 100 points upar aur neeche ke options filter karna
#     df = df[
#         (df["Strike price"] >= atm_strike - 100)
#         & (df["Strike price"] <= atm_strike + 100)
#     ]

#     # Top PE aur bottom CE options ko filter karna
#     top_pe = df[
#         (df["Option type"] == "PE") & (df["Strike price"] == atm_strike)
#     ].nlargest(1, "Strike price")
#     bottom_ce = df[
#         (df["Option type"] == "CE") & (df["Strike price"] == atm_strike)
#     ].nsmallest(1, "Strike price")

#     # Combine karke return karna
#     result = pd.concat([top_pe, bottom_ce])

#     return result[["Symbol ticker", "Strike price", "Option type"]]


def filter_data(df, lot_size, index, atm_strike, otm):

    df = df[df["Minimum lot size"] == lot_size].copy()
    df = df[df["Underlying symbol"] == index]
    df["Expiry date"] = df["Expiry date"].apply( lambda x: dt.datetime.fromtimestamp(int(x)).date() )
    expiry = min(df["Expiry date"].unique())
    df = df[df["Expiry date"] == expiry]
    if "Unnamed: 0" in df.columns:
        df = df.drop("Unnamed: 0", axis=1)
    df = df[ (df["Strike price"] >= atm_strike - otm * 100) & (df["Strike price"] <= atm_strike + otm * 100) ]
    top_pe = df[df["Option type"] == "CE"].nlargest(1, "Strike price")
    bottom_ce = df[df["Option type"] == "PE"].nsmallest(1, "Strike price")
    result = pd.concat([top_pe, bottom_ce])
    return result[["Symbol ticker", "Strike price", "Option type"]]


def filter_data_sny(df, index, lot):
    df = df[(df["Exchange"] == "NFO") & (df["LotSize"] == lot)].copy()
    df = df[df["Symbol"] == index]
    df["Expiry"] = pd.to_datetime(df["Expiry"], format="mixed")
    df = df[df["Expiry"] == min(df["Expiry"].unique())]
    return df


def get_candle_data(fyers, symbol, interval, from_date, to_date, lenth1, lenth2):
    # try:
        data = {
            "symbol": symbol,
            "resolution": interval,
            "date_format": "1",
            "range_from": from_date,
            "range_to": to_date,
            "cont_flag": "1",
        }
        resp = fyers.history(data=data)
        df = pd.DataFrame(
            resp["candles"], columns=["date", "open", "high", "low", "close", "volume"]
        )
        df["date"] = df["date"].apply(lambda x: dt.datetime.fromtimestamp(x))
        # df[["SUPERT_10_3.0", "SUPERTd_10_3.0", "SUPERTl_10_3.0", "SUPERTs_10_3.0"]] = (
        #     ta.supertrend(df.high, df.low, df.close, length=10, multiplier=3)
        # )
        # df['ema1'] = round(tas.EMA(df['close'], timeperiod=lenth1),2)
        # df['ema9'] = round(tas.EMA(df['close'], timeperiod=lenth2),2)

        df["ema1"] = round(ta.ema(df["close"], length=lenth1),2)
        df["ema9"] = round(ta.ema(df["close"], length=lenth2),2)
        df = df.set_index("date")
        df = df.reset_index()
        return df


def data_downloader2(fyers, event, symbol_list, interval, from_date, to_date, candle_data, lenth1, lenth2):
    try:
        while dt.datetime.now().time() <= dt.time(22, 30):
            try:
                sleep(1)
                if event.is_set():
                    print("Stop Data Downloader..")
                    break
                if (
                    dt.datetime.now().minute % interval == 0 and dt.datetime.now().second == 0
                ) or not candle_data:

                    def data(symbol):
                        while True:
                            try:
                                df = get_candle_data(
                                    fyers, symbol, interval, from_date, to_date, lenth1, lenth2
                                )
                                candle_data[symbol] = df
                                break
                            except Exception as e:
                                sleep(1)
                                print(f"Data Error {e}")
                                # traceback.print_exc()
                                # break

                    with TRD() as exc:
                        exc.map(data, symbol_list)
                    print("Data Downloaded ..........................")
            except Exception as e:
                print(f"Error occurred: {e}")
                event.set()
                break
    except Exception as e:
        print(f"Critical Error occurred: {e}")
        event.set()




def data_downloader(fyers, event, symbol_list, interval, from_date, to_date, candle_data, lenth1, lenth2):
    error_flag = False

    while dt.datetime.now().time() <= dt.time(22, 30):
        sleep(1)
        if event.is_set() or error_flag:
            print("Stop Data Downloader..")
            break
        if (
            dt.datetime.now().minute % interval == 0 and dt.datetime.now().second == 0
        ) or not candle_data:

            def data(symbol):
                nonlocal error_flag
                while True:
                    try:
                        df = get_candle_data(
                                    fyers, symbol, interval, from_date, to_date, lenth1, lenth2
                                )
                        candle_data[symbol] = df
                        break
                    except Exception as e:
                        sleep(1)
                        # print(f"Data Error {e}")
                        error_flag = True
                        break

            with TRD() as exc:
                exc.map(data, symbol_list)
            if error_flag:
                break
            print("Data Downloaded ..........................")


# def placeOrder(fyers, symbol, qty, side):
#     data = {
#         "symbol": symbol,
#         "qty": qty,
#         "type": 2,
#         "side": side,
#         "productType": "INTRADAY",
#         "limitPrice": 0,
#         "stopPrice": 0,
#         "validity": "DAY",
#         "disclosedQty": 0,
#         "offlineOrder": False,
#     }
#     return fyers.place_order(data=data)


def placeOrder(api, symbol, qty, direction):

    ret = api.place_order(
        buy_or_sell=direction,
        product_type="M",
        exchange="NFO",
        tradingsymbol=symbol,
        quantity=abs(qty),
        discloseqty=0,
        price_type="MKT",
        retention="DAY",
    )
    return ret


def get_atm_value(ltp, gap):
    return 100 * round(ltp / gap)


def index_atm(fyers, index):
    data = {"symbols": f"NSE:{index}-INDEX"}
    response = fyers.quotes(data=data)
    ltp = response["d"][0]["v"]["lp"]
    atm = 100 * round(ltp / 100)
    return atm


def getSymbol(df, strike, cepe):
    return df[(df["StrikePrice"] == strike) & (df["OptionType"] == cepe)][
        "TradingSymbol"
    ].iloc[0]





def login(apps_id,secret_keys,fyr_id, totps,pin):
    today = str(dt.date.today())
    file_name = f"access_token{today}.txt"
    file_path = os.path.join("utils", file_name)
    if not os.path.exists(file_path):
        APP_ID = apps_id
        APP_TYPE = "100"
        SECRET_KEY = secret_keys
        client_id = f"{APP_ID}-{APP_TYPE}"

        FY_ID = fyr_id
        APP_ID_TYPE = "2"
        TOTP_KEY = totps
        PIN = pin

        REDIRECT_URI = "https://www.google.com/"
        BASE_URL = "https://api-t2.fyers.in/vagator/v2"
        BASE_URL_2 = "https://api.fyers.in/api/v2"
        URL_SEND_LOGIN_OTP = BASE_URL + "/send_login_otp"
        URL_VERIFY_TOTP = BASE_URL + "/verify_otp"
        URL_VERIFY_PIN = BASE_URL + "/verify_pin"
        URL_TOKEN = BASE_URL_2 + "/token"
        URL_VALIDATE_AUTH_CODE = BASE_URL_2 + "/validate-authcode"
        SUCCESS = 1
        ERROR = -1

        def send_login_otp(fy_id, app_id):
            try:
                result_string = rq.post(url=URL_SEND_LOGIN_OTP, json= {"fy_id": fy_id, "app_id": app_id })
                if result_string.status_code != 200:
                    return [ERROR, result_string.text]
                result = json.loads(result_string.text)
                request_key = result["request_key"]
                return [SUCCESS, request_key]
            except Exception as e:
                return [ERROR, e]

        def verify_totp(request_key, totp):
            try:
                result_string = rq.post(url=URL_VERIFY_TOTP, json={"request_key": request_key,"otp": totp})
                if result_string.status_code != 200:
                    return [ERROR, result_string.text]
                result = json.loads(result_string.text)
                request_key = result["request_key"]
                return [SUCCESS, request_key]
            except Exception as e:
                return [ERROR, e]

        session = fyersModel.SessionModel(client_id=client_id, secret_key=SECRET_KEY, redirect_uri=REDIRECT_URI,
                                    response_type='code', grant_type='authorization_code')
        urlToActivate = session.generate_authcode()
        # print(urlToActivate)
        # sys.exit()
        send_otp_result = send_login_otp(fy_id=FY_ID, app_id=APP_ID_TYPE)

        if send_otp_result[0] != SUCCESS:
            print(f"send_login_otp failure - {send_otp_result[1]}")
            sys.exit()
        else:
            print("send_login_otp success")

        for i in range(1,3):
            request_key = send_otp_result[1]
            verify_totp_result = verify_totp(request_key=request_key, totp=pyotp.TOTP(TOTP_KEY).now())
            if verify_totp_result[0] != SUCCESS:
                print(f"verify_totp_result failure - {verify_totp_result[1]}")
                time.sleep(1)
            else:
                print(f"verify_totp_result success")
                break

        request_key_2 = verify_totp_result[1]
        ses = rq.Session()
        payload_pin = {"request_key":f"{request_key_2}","identity_type":"pin","identifier":f"{PIN}","recaptcha_token":""}
        res_pin = ses.post('https://api-t2.fyers.in/vagator/v2/verify_pin', json=payload_pin).json()
        ses.headers.update({
            'authorization': f"Bearer {res_pin['data']['access_token']}"})

        authParam = {"fyers_id":FY_ID,"app_id":APP_ID,"redirect_uri":REDIRECT_URI,"appType":APP_TYPE,"code_challenge":"","state":"None","scope":"","nonce":"","response_type":"code","create_cookie":True}
        authres = ses.post('https://api-t1.fyers.in/api/v3/token', json=authParam).json()
        print(authres)

        url = authres['Url']

        parsed = urlparse(url)
        auth_code = parse_qs(parsed.query)['auth_code'][0]

        session.set_token(auth_code)
        response = session.generate_token()
        access_token= response["access_token"]

        today = str(dt.date.today())
        folder_path = 'utils'

            # Folder ke saari files ko list karein
        for filename in os.listdir(folder_path):
            # Check karein agar filename 'data' se start hoti hai
            if filename.startswith('access') and filename.endswith('.txt'):
                file_path = os.path.join(folder_path, filename)
                # File ko remove karen
                os.remove(file_path)

        with open(f"utils/access_token{today}.txt","w") as file:
            file.write(access_token)

        fyers = fyersModel.FyersModel(client_id=client_id, token=access_token, log_path='utils/')
        print(f"Welcome .. {fyers.get_profile()['data']['name']} .. ")
        print("Login Successfully")
    else:
        print("already login")



# with open(f"utils/login_data.json", "r") as f:
#     Cread = json.load(f)

# fyr_id = Cread["FYERS ID"]
# apps_id = Cread["APP ID"]
# secret_keys = Cread["SECRET KEY"]
# totps = Cread["TOTP"]
# pin = Cread["PIN"]
# # pdb.set_trace()

# login(apps_id, secret_keys, fyr_id, totps, pin)

