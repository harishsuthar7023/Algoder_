import sys
import os
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QFormLayout, QLabel,
    QLineEdit, QPushButton, QComboBox, QSpinBox, QScrollArea, QFrame, QMenuBar, QMessageBox, QTextEdit,QToolButton
)
from PyQt6.QtGui import QAction,QIcon
from PyQt6.QtCore import Qt, QTimer, QDateTime,QMetaObject ,Q_ARG
import threading
import json
import datetime as dt


from strategy import main_logic

fyers = None
access_token = None

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Trade Tool')
        self.setGeometry(800, 100, 400, 500)

        # Central widget
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.main_layout = QVBoxLayout(self.central_widget)

        # Menu Bar
        menu_bar = QMenuBar(self)
        self.setMenuBar(menu_bar)

        login_menu = menu_bar.addMenu('Menu')

        open_login_action = QAction('Login', self)
        open_login_action.triggered.connect(self.open_login_frame)
        login_menu.addAction(open_login_action)

        open_trade_action = QAction('Trade', self)
        open_trade_action.triggered.connect(self.open_trade_frame)
        login_menu.addAction(open_trade_action)

        open_close_position_action = QAction('History', self)
        open_close_position_action.triggered.connect(self.open_close_position_frame)
        login_menu.addAction(open_close_position_action)

        # Scroll Area for trade tool
        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll_content = QWidget()
        self.scroll_layout = QVBoxLayout(self.scroll_content)

        self.init_trade_tool()

        self.scroll.setWidget(self.scroll_content)
        self.main_layout.addWidget(self.scroll)

        # Login Frame
        self.login_frame = QFrame()
        self.login_frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.init_login_frame()

        # Close Position Frame
        self.close_position_frame = QFrame()
        self.close_position_frame.setFrameShape(QFrame.Shape.StyledPanel)
        self.init_close_position_frame()

        # QTimer for updating the log file display
        self.log_update_timer = QTimer(self)
        self.log_update_timer.timeout.connect(self.update_log_file_display)
        self.log_update_timer.start(1000)

        self.load_settings()
        self.load_settings_for_login()

    def txt(self, labelx):
        labelx.setStyleSheet("QLabel { font-size: 16px; font-family: 'Arial';}")

    def init_trade_tool(self):
        trade_title = QLabel('Trade Tool')
        trade_title.setStyleSheet('font-size: 20px; font-weight: bold; text-align: center; margin: 20px;')
        self.scroll_layout.addWidget(trade_title, alignment=Qt.AlignmentFlag.AlignCenter)

        trade_form_layout = QFormLayout()

        labelx = QLabel('Index:')
        self.select_index_input = QComboBox()
        self.select_index_input.setStyleSheet("QComboBox { font: 12px; padding: 3px 10px;}")
        self.select_index_input.addItems(['BANKNIFTY', 'NIFTY', 'FINNIFTY'])
        trade_form_layout.addRow(labelx, self.select_index_input)

        self.interval_input = QComboBox()
        self.interval_input.setStyleSheet("QComboBox { font: 12px; padding: 3px 10px;}")
        self.interval_input.addItems(['1', '5', '15'])
        trade_form_layout.addRow('Interval:', self.interval_input)

        self.otm_input = QSpinBox()
        self.otm_input.setStyleSheet("QSpinBox { font: 12px; padding: 3px 1px;}")
        self.otm_input.setValue(100)
        trade_form_layout.addRow('Otm:', self.otm_input)

        self.target_input = QSpinBox()
        self.target_input.setValue(1)
        trade_form_layout.addRow('Target:', self.target_input)

        self.stoploss_input = QSpinBox()
        self.stoploss_input.setValue(1)
        trade_form_layout.addRow('Stoploss:', self.stoploss_input)

        self.quantity_input = QSpinBox()
        self.quantity_input.setValue(1)
        trade_form_layout.addRow('Quantity:', self.quantity_input)

        self.ema1_input = QSpinBox()
        self.ema1_input.setValue(1)
        trade_form_layout.addRow('EMA 1:', self.ema1_input)

        self.ema2_input = QSpinBox()
        self.ema2_input.setValue(1)
        trade_form_layout.addRow('EMA 2:', self.ema2_input)

        self.scroll_layout.addLayout(trade_form_layout)

        submit_button = QPushButton('Submit')
        submit_button.clicked.connect(self.on_submit_click)
        self.scroll_layout.addWidget(submit_button, alignment=Qt.AlignmentFlag.AlignCenter)

        # Log display
        self.log_text_edit = QTextEdit()
        self.log_text_edit.setReadOnly(True)
        self.log_text_edit.setFixedHeight(500)  # Set the height of the log file display to 500
        self.scroll_layout.addWidget(self.log_text_edit)

    def init_login_frame(self):
        login_frame_layout = QVBoxLayout(self.login_frame)
        login_title = QLabel('Login')
        login_title.setStyleSheet('font-size: 20px; font-weight: bold; text-align: center;')
        login_frame_layout.addWidget(login_title, alignment=Qt.AlignmentFlag.AlignCenter)

        login_form_layout = QFormLayout()

        self.fyers_id_input = QLineEdit()
        login_form_layout.addRow('FYERS ID:', self.fyers_id_input)

        self.app_id_input = QLineEdit()
        login_form_layout.addRow('APP ID:', self.app_id_input)

        self.secret_key_input = QLineEdit()
        # self.secret_key_input.setEchoMode(QLineEdit.EchoMode.Password)
        login_form_layout.addRow('SECRET KEY:', self.secret_key_input)

        self.totp_input = QLineEdit()
        login_form_layout.addRow('TOTP:', self.totp_input)

        self.pin_input = QLineEdit()
        self.pin_input.setEchoMode(QLineEdit.EchoMode.Password)

        self.show_password_button = QToolButton(self.pin_input)
        self.show_password_button.setIcon(QIcon("utils/hide.png"))  # Path to eye icon
        self.show_password_button.setCheckable(True)
        self.show_password_button.setCursor(Qt.CursorShape.PointingHandCursor)

        self.show_password_button.setStyleSheet("""
            QToolButton {
                border: none;
                background: transparent;
            }
        """)

        self.show_password_button.clicked.connect(self.toggle_password_visibility)

        # Add button inside QLineEdit
        self.pin_input.setLayout(QVBoxLayout())
        self.pin_input.layout().setContentsMargins(0, 0, 5, 0)
        self.pin_input.layout().addWidget(self.show_password_button, alignment=Qt.AlignmentFlag.AlignRight)


        login_form_layout.addRow('PIN:', self.pin_input)
        # self.pin_input.setStyleSheet('padding:1px;')
        login_frame_layout.addLayout(login_form_layout)

        login_button = QPushButton('Save')
        login_button.clicked.connect(self.save_input_values)
        login_frame_layout.addWidget(login_button, alignment=Qt.AlignmentFlag.AlignCenter)


    def toggle_password_visibility(self):
        if self.show_password_button.isChecked():
            self.pin_input.setEchoMode(QLineEdit.EchoMode.Normal)
            self.show_password_button.setIcon(QIcon("utils/eye.png"))  # Path to eye-off icon
        else:
            self.pin_input.setEchoMode(QLineEdit.EchoMode.Password)
            self.show_password_button.setIcon(QIcon("utils/hide.png"))



    def init_close_position_frame(self):
        close_position_frame_layout = QVBoxLayout(self.close_position_frame)
        close_position_title = QLabel('History')
        close_position_title.setStyleSheet('font-size: 20px; font-weight: bold; text-align: center;')
        close_position_frame_layout.addWidget(close_position_title, alignment=Qt.AlignmentFlag.AlignCenter)

        self.log_files_scroll = QScrollArea()
        self.log_files_scroll.setWidgetResizable(True)
        self.log_files_content = QWidget()
        self.log_files_layout = QVBoxLayout(self.log_files_content)

        self.load_log_files()

        self.log_files_scroll.setWidget(self.log_files_content)
        close_position_frame_layout.addWidget(self.log_files_scroll)

    def load_log_files(self):
        log_folder = "TRADE_LOG"
        if not os.path.exists(log_folder):
            os.makedirs(log_folder)
        log_files = os.listdir(log_folder)
        log_files.sort(reverse=True)  # Sort the files in reverse order

        for log_file in log_files:
            log_frame = QFrame()
            log_frame.setFrameShape(QFrame.Shape.StyledPanel)
            log_frame_layout = QVBoxLayout(log_frame)
            log_title = QLabel(log_file)
            log_title.setStyleSheet('font-size: 16px; font-weight: bold;')
            log_frame_layout.addWidget(log_title)

            log_text_edit = QTextEdit()
            log_text_edit.setReadOnly(True)
            log_text_edit.setFixedHeight(200)
            with open(os.path.join(log_folder, log_file), 'r') as file:
                log_text_edit.setPlainText(file.read())
            log_frame_layout.addWidget(log_text_edit)

            self.log_files_layout.addWidget(log_frame)
            self.log_files_layout.addWidget(log_frame)

    def open_login_frame(self):
        self.main_layout.removeWidget(self.scroll)
        self.main_layout.removeWidget(self.close_position_frame)
        self.scroll.setParent(None)
        self.close_position_frame.setParent(None)
        self.main_layout.addWidget(self.login_frame)

    def open_trade_frame(self):
        self.main_layout.removeWidget(self.login_frame)
        self.main_layout.removeWidget(self.close_position_frame)
        self.login_frame.setParent(None)
        self.close_position_frame.setParent(None)
        self.main_layout.addWidget(self.scroll)
        self.load_log_file()

    def open_close_position_frame(self):
        self.main_layout.removeWidget(self.scroll)
        self.main_layout.removeWidget(self.login_frame)
        self.scroll.setParent(None)
        self.login_frame.setParent(None)
        self.main_layout.addWidget(self.close_position_frame)

    def save_input_values(self):
        if not all([self.fyers_id_input.text(), self.app_id_input.text(), self.secret_key_input.text(), self.totp_input.text(), self.pin_input.text()]):
            QMessageBox.critical(self, "Input Error", "Please ensure all inputs are filled correctly.")
            return
        confirm = QMessageBox.question(self, "Confirm Details", "Please confirm that all details are correct. Do you want to proceed?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if confirm != QMessageBox.StandardButton.Yes:
            return
        self.input_data = {
            "FYERS_ID": str(self.fyers_id_input.text()),
            "APP_ID": str(self.app_id_input.text()),
            "SECRET_KEY": str(self.secret_key_input.text()),
            "TOTP": str(self.totp_input.text()),
            "PIN": str(self.pin_input.text())
        }
        with open("secret.json", "w") as file:
            json.dump(self.input_data, file)
        global fyers, access_token
        fyers, access_token = main_logic(self.input_data)
        self.open_trade_frame()

    def submit(self, index, interval, otm, target, stoploss, quantity, ema1, ema2):
        try:
            data = {
                "index": index.currentText(),
                "interval": int(interval.currentText()),
                "otm": int(otm.value()),
                "target": int(target.value()),
                "stoploss": int(stoploss.value()),
                "quantity": int(quantity.value()),
                "ema1": int(ema1.value()),
                "ema2": int(ema2.value()),
            }
            # Data stored in variable
            submitted_data = data
            # self.update_log(f"Submitted Data: {data}")
            main_logic(data["index"], data["interval"], data["otm"], data["target"], data["stoploss"], data["quantity"], data["ema1"], data["ema2"])
        except ValueError:
            QMetaObject.invokeMethod(self, "show_error_message", Qt.ConnectionType.QueuedConnection, Q_ARG(str, "Please ensure all inputs are filled correctly."))

    def show_error_message(self, message):
        QMessageBox.critical(self, "Input Error", message)

    def call_submit(self, index, interval, otm, target, stoploss, quantity, ema1, ema2):
        threading.Thread(target=self.submit, args=(index, interval, otm, target, stoploss, quantity, ema1, ema2)).start()



    def on_submit_click(self):
        # Trigger the call_submit method when the button is clicked
        self.call_submit(self.select_index_input, self.interval_input, self.otm_input, self.target_input, self.stoploss_input, self.quantity_input, self.ema1_input, self.ema2_input)

        # Call the logic to process the data (You need to implement this part)
        # process_trade(index, interval, otm, target, stoploss, quantity, ema1, ema2)

    def load_log_file(self):
        try:
            today = str(dt.date.today())
            with open(f"TRADE_LOG/{today}.log", "r") as log_file:
                self.log_text_edit.setPlainText(log_file.read())
        except FileNotFoundError:
            self.log_text_edit.setPlainText("Log file not found.")

    def update_log_file_display(self):
        try:
            today = str(dt.date.today())
            with open(f"TRADE_LOG/{today}.log", "r") as log_file:
                current_text = self.log_text_edit.toPlainText()
                new_text = log_file.read()
                if (current_text != new_text):
                    self.log_text_edit.setPlainText(new_text)
                    self.log_text_edit.verticalScrollBar().setValue(self.log_text_edit.verticalScrollBar().maximum())
        except FileNotFoundError:
            self.log_text_edit.setPlainText("Log file not found.")

    def update_log(self, message):
        timestamp = QDateTime.currentDateTime().toString("yyyy-MM-dd HH:mm:ss")
        log_entry = f"{timestamp} - {message}\n"
        today = str(dt.date.today())
        with open(f"TRADE_LOG/{today}.log", "a") as log_file:
            log_file.write(log_entry)





    def on_closing(self):
        settings = {
            "index": self.select_index_input.currentText(),
            "interval": self.interval_input.currentText(),
            "otm": self.otm_input.text(),
            "qty": self.quantity_input.text(),
            "sl": self.stoploss_input.text(),
            "tgt": self.target_input.text(),
            "lenth1": self.ema1_input.text(),
            "lenth2": self.ema2_input.text(),
        }

        with open("settings_main.json", "w") as file:
            json.dump(settings, file)

        # Close the window
        self.close()

    def load_settings(self):
        if os.path.exists("settings_main.json"):
            with open("settings_main.json", "r") as file:
                settings = json.load(file)

                self.select_index_input.setCurrentText(settings.get("index", ''))
                self.interval_input.setCurrentText(settings.get("interval", ''))
                self.otm_input.setValue(int(settings.get("otm", "")))
                self.quantity_input.setValue(int(settings.get("qty", "")))
                self.stoploss_input.setValue(int(settings.get("sl", "")))
                self.target_input.setValue(int(settings.get("tgt", "")))
                self.ema1_input.setValue(int(settings.get("lenth1", "")))
                self.ema2_input.setValue(int(settings.get("lenth2", "")))


    def load_settings_for_login(self):
        if os.path.exists("utils/login_data.json"):
            with open("utils/login_data.json", "r") as file:
                settings = json.load(file)
                self.fyers_id_input.setText(settings.get("FYERS ID", ""))
                self.app_id_input.setText(settings.get("APP ID", ""))
                self.secret_key_input.setText(settings.get("SECRET KEY", ""))
                self.totp_input.setText(settings.get("TOTP", ""))
                self.pin_input.setText(settings.get("PIN", ""))

    def closeEvent(self, event):
        # This method is called when the window is closing
        self.on_closing()
        event.accept()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    main_window = MainWindow()
    main_window.show()
    sys.exit(app.exec())

