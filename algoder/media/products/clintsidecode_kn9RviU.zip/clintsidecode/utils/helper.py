import pandas as pd
import datetime as dt
import os
import requests
import json, re
import upstox_client
from upstox_client.rest import ApiException
from time import sleep
import sys
import pdb
from concurrent.futures import ThreadPoolExecutor as TRD
import logging

def logging_data(LOG_FILE):
    logging.basicConfig(
        format="%(asctime)s %(message)s",
        datefmt="%H:%M:%S",  # Sirf Hours:Minutes:Seconds ke liye
        level=logging.INFO,
        handlers=[logging.FileHandler(LOG_FILE, "a"), logging.StreamHandler()],
    )
    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    return logger



def download_instruments():
    today = str(dt.date.today())
    filename = f"utils/Data_{today}.csv"
    if not os.path.exists(filename):
        print("Data Downloading..")
        for i in os.listdir("utils"):
            if i.startswith("Data"):
                os.remove(f"utils/{i}")
                print("File Deleted")

        fileUrl = "https://assets.upstox.com/market-quote/instruments/exchange/complete.csv.gz"
        inst = pd.read_csv(fileUrl)
        inst.to_csv(f"{filename}")
        print("File Downloaded123")
    return pd.read_csv(f"{filename}")


# def get_candle_data(interval, instrument_key, to_date, from_date, access_token):

#     url = f"https://api.upstox.com/v3/historical-candle/{instrument_key}/minutes/{interval}/{to_date}/{from_date}"
#     payload = {}
#     headers = {
#         "accept": "application/json",
#         "Api-Version": "3.0",
#         "Authorization": f"Bearer {access_token}",
#     }
#     response = requests.get(url, headers=headers).json()
#     # Convert the response data into a DataFrame
#     data = pd.DataFrame(response["data"]["candles"])
#     data.columns = ["date", "open", "high", "low", "close", "volume", "oi"]
#     # Store the DataFrame in the dictionary using instrument_key as the key
#     # candle_data[instrument_key] = data
#     # print(candle_data[instrument_key])  # To display the stored DataFrame
#     return data


# def data_downloader(event,interval,sym,symbol_list, to_date, from_date, access_token, candle_data):
#     try:
#         while dt.datetime.now().time() <= dt.time(22, 30):
#             try:
#                 sleep(1)
#                 if event.is_set():
#                     print("Stop Data Downloader..")
#                     break
#                 if (dt.datetime.now().minute % interval == 0 and dt.datetime.now().second == 0) or not candle_data:
#                     def data(instrument_key,symbol):
#                         while not event.is_set():
#                             try:
#                                 df = get_candle_data(interval, instrument_key, to_date, from_date, access_token,)
#                                 candle_data[symbol] = df
#                                 # print(df)
#                                 break
#                             except Exception as e:
#                                 sleep(1)
#                                 print(f"Data Error {e}")
#                                 event.set()
#                                 break
#                     with TRD() as exc:
#                         exc.map(data, symbol_list,sym)
#                     print("Data Downloaded ..........................")
#             except Exception as e:
#                 print(f"Error in data downloader: {e}")
#                 # event.set()
#                 # break
#     except KeyboardInterrupt:
#         print("Data downloader stopped by user.")

def filter_data(df, index, atm_strike, otm):
    # Filter minimum lot size aur underlying symbol ke basis par
    # df = df[df["Minimum lot size"] == lot_size].copy()
    df = df[df["name"] == index]
    # df["Expiry date"] = df["Expiry date"].apply(
    #     lambda x: dt.datetime.fromtimestamp(int(x)).date()
    # )

    # Sabse kareeb expiry date ko find karna aur uske basis par filter karna
    expiry = df["expiry"].min()
    df = df[df["expiry"] == expiry]

    # Unnamed: 0 column ko drop karna (agar exist karta ho)
    if "Unnamed: 0" in df.columns:
        df = df.drop("Unnamed: 0", axis=1)

    # ATM strike ke 100 points upar aur neeche ke options filter karna
    df = df[
        (df["strike"] >= atm_strike - otm * 100)
        & (df["strike"] <= atm_strike + otm * 100)
    ]

    # Top PE aur bottom CE options ko filter karna
    # top_pe = df[df["option_type"] == "CE"].nlargest(1, "strike")
    top_pe = df[df["option_type"] == "CE"].nsmallest(1, "strike")
    bottom_ce = df[df["option_type"] == "PE"].nlargest(1, "strike")

    # Combine karke return karna
    df = pd.concat([top_pe, bottom_ce])
    data = {}
    # print(result)
    for i in df.index:
        symbol = df["tradingsymbol"][i]
        token = df["instrument_key"][i]
        # print(symbol)
        data[token] = symbol

    return data


def get_strike(access_token):
    configuration = upstox_client.Configuration()
    configuration.access_token = access_token
    api_instance = upstox_client.MarketQuoteApi(upstox_client.ApiClient(configuration))
    symbol = 'NSE_INDEX|Nifty 50' # str | Comma separated list of symbols
    symbol2 = 'NSE_INDEX:Nifty 50' # str | Comma separated list of symbols
    api_version = '2.0'
    api_response = api_instance.get_full_market_quote(symbol, api_version)
    response_dict = api_response.to_dict()
    ltp = response_dict["data"][symbol2]["last_price"]

    atm = 100 * round(ltp / 100)
    return atm



def order_place(access_token,qty,index,bysl):
    url = "https://api-hft.upstox.com/v3/order/place"
    payload = json.dumps({
    "quantity": qty,
    "product": "I",
    "validity": "DAY",
    "price": 0,
    "tag": "string",
    "instrument_token": index,
    "order_type": "MARKET",
    "transaction_type": bysl,
    "disclosed_quantity": 0,
    "trigger_price": 0,
    "is_amo": False
    })
    headers = {
    'Content-Type': 'application/json',
    'Authorization' : f'Bearer {access_token}',
    'Accept' : 'application/json'
    }
    response = requests.request("POST", url, headers=headers, data=payload)

    print(response.text)

