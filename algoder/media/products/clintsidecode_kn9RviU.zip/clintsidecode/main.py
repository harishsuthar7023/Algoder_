from utils.helper import *
from utils.login import *
from threading import Thread,Event
import traceback

LOG_FILE = f'TRADE_LOG/{str(dt.date.today())}.log'
logging = logging_data(LOG_FILE)
logging.info("Tnank you for chosing Algoder! Starting the Algo...")

today = str(dt.date.today())
tokenFile = f"utils/accessToken{today}.txt"
if not os.path.exists(tokenFile):
    for i in os.listdir("utils"):
        if i.startswith("accessToken"):
            os.remove(f"utils/{i}")
    login()
with open(f"{tokenFile}", "r") as file:
    access_token = file.read()
access_token

inst = download_instruments()

from_date = (dt.datetime.now() - dt.timedelta(days=10)).date()
to_date = dt.datetime.now().date()

index = "NIFTY"
intru = ['NSE_INDEX|Nifty 50']

otm = 3

strike = get_strike(access_token)
print(strike)
symbols = filter_data(inst,index, strike, otm)

instrument_token = list(symbols.keys())
trading_sym = list(symbols.values())

instrunet = instrument_token + intru


print(f"inst {instrunet}, insts {instrument_token}")

ltp_data = {}

while True:
    if dt.datetime.now().time() >= dt.time(9, 45):
        break


def on_message(message):
    # sleep()
    # print(f"on_message: {message}")
    try:
        for k, v in message["feeds"].items():
            tiker = str(k)
            # print(f"tiker: {tiker}")
            # print(f"v: {v}")
            sym = k
            if tiker != "NSE_INDEX|Nifty 50":
                # print(f"tiker: {tiker} not Nifty 50")
                ltp = v["ff"]["marketFF"]["ltpc"]["ltp"]
                Open = None
                high = None
                low = None
                close = None
            if tiker == "NSE_INDEX|Nifty 50":
                ltp = v["ff"]["indexFF"]["ltpc"]["ltp"]
                i30_candles = [candle for candle in v["ff"]["indexFF"]["marketOHLC"]["ohlc"] if candle["interval"] == "I30"]
                # print(f"i30_candles: {i30_candles}",ltp)
                second_last_i30 = i30_candles[-2]
                Open = second_last_i30["open"]
                high = second_last_i30["high"]
                low = second_last_i30["low"]
                close = second_last_i30["close"]

            ltp_data[sym] = {"ltp": ltp, "open": Open, "high": high, "low": low, "close": close}
    except Exception as e:
        print(f"Error in on_message: {e}")

configuration = upstox_client.Configuration()
configuration.access_token = access_token
streamer = upstox_client.MarketDataStreamer(
    upstox_client.ApiClient(configuration), instrunet, "full"
)
streamer.on("message", on_message)
streamer.connect()
print("webSocket connected")
sleep(8)


status = {
    x: {
        "traded": None,
        "price": None,
        "qty": None,
        "sl": None,
        "tsl": None,
        "tgt": None,
        "lastTrade": None,
        "sym": None
    }
    for x in instrument_token 
}

trade = 0
buy = None
sym = None
callReverse = False
putReverse = False
all_exit = None
tgt = 40
pnl = 0

logging.info(symbols)

try:
    while True:
        # sleep(1)
        # print(f"ltp_data: {ltp_data}")
        # break
        sleep(0.5)
        try:
            # if:
            for t , i in symbols.items():
                ltp = ltp_data["NSE_INDEX|Nifty 50"]['ltp']
                close = ltp_data["NSE_INDEX|Nifty 50"]["close"]
                high = ltp_data["NSE_INDEX|Nifty 50"]["high"]
                low = ltp_data["NSE_INDEX|Nifty 50"]["low"]
                Open = ltp_data["NSE_INDEX|Nifty 50"]["open"]

                if dt.datetime.now().minute % 3 == 0 and dt.datetime.now().second == 0 and status[list(status)[0]]["traded"] == None and status[list(status)[1]]["traded"] == None:
                    atm_strike = get_strike(access_token)

                    if atm_strike != strike:
                        symbols = {}
                        symbols = filter_data(inst,index, atm_strike, otm)
                        streamer.subscribe(list(symbols.keys()))
                        sleep(0.5)
                        logging.info(f"New Strike price{symbols.values()}")
                        
                        status = {
                            x: {
                                "traded": None,
                                "price": None,
                                "qty": None,
                                "sl": None,
                                "tsl": None,
                                "tgt": None,
                                "diff": None,
                                "lastTrade": None
                            }
                            for x in list(symbols.values())
                        }
                        break

                if buy == None and status[t]["traded"] == None and  dt.datetime.now().time() >= dt.time(9, 45) and dt.datetime.now().time() <= dt.time(10, 30):
                    # print(f"open {Open} high {high} low {low} close {close} ltp {ltp}")
                    if close > Open and i.endswith("CE"):
                        # order_place(access_token,75,t,"BUY")
                        status[t]["traded"] = "call"
                        status[t]["tgt"] = ltp + tgt
                        status[t]["sl"] = ltp - tgt
                        status[t]["qty"] = 75
                        logging.info(f"call Entry in {i} at {ltp} tgt: {status[t]['tgt']} sl: {status[t]['sl']} , qty: {status[t]['qty']}")
                        buy = True
                        sym = t
                        
                    elif Open > close and i.endswith("PE"):
                        # order_place(access_token,75,t,"BUY")
                        status[t]["traded"] = "put"
                        status[t]["tgt"] = ltp + tgt
                        status[t]["sl"] = ltp - tgt
                        status[t]["qty"] = 75
                        sym = t
                        buy = True
                        logging.info(f"put Entry in {i} at {ltp} tgt: {status[t]['tgt']} sl: {status[t]['sl']}, qty:{ status[t]['qty']}")

                elif sym:
                    if status[sym]["traded"] == "call" and status[sym]["tgt"] < ltp and i.endswith("CE"):
                        logging.info(f"call target hit in {sym} at {ltp} qty:{status[sym]['qty']}")
                        # order_place(access_token,status[sym]["qty"],sym,"SELL")
                        oid = f"order placement {sym}"
                        if oid :
                            all_exit = True
                            break

                    elif status[sym]["traded"] == "put" and status[sym]["tgt"] < ltp and i.endswith("PE"):
                        logging.info(f"put target hit in {sym} at {ltp} qty:{status[sym]['qty']}")
                        # order_place(access_token,status[sym]["qty"],sym,"SELL")
                        oid = "order placement  "
                        if oid :
                            all_exit = True
                            break

                    elif status[sym]["traded"] == "call" and status[sym]["sl"] > ltp and i.endswith("CE"):

                        # order_place(access_token,status[sym]["qty"],sym,"SELL")
                        oid = "order placement"
                        trade += 1
                        logging.info(f"call {trade} stop loss hit in {sym} at {ltp} qty:{status[sym]['qty']}")
                        status[sym]["traded"] = None
                        status[sym]["tgt"] = None
                        status[sym]["sl"] = None
                        status[sym]["qty"] = None
                        callReverse = True
                        sym = None
                        if trade > 2:
                            logging.info("yes all exit")
                            all_exit = True
                            break

                    elif status[sym]["traded"] == "put" and status[sym]["sl"] > ltp and i.endswith("PE"):

                        # order_place(access_token,status[sym]["qty"],sym,"SELL")
                        oid = "order placement"
                        trade += 1
                        logging.info(f"put {trade} stop loss hit in {sym} at {ltp} qty: {status[sym]['qty']}")
                        status[sym]["traded"] = None
                        status[sym]["tgt"] = None
                        status[sym]["sl"] = None
                        status[sym]["qty"] = None
                        putReverse = True
                        sym = None
                        if trade > 2:
                            logging.info("yes all exit")
                            all_exit = True
                            break

                if callReverse and i.endswith("PE"):
                    # order_place(access_token,150,t,"BUY")
                    oid = "order placement 2 lot"
                    status[t]["traded"] = "put"
                    status[t]["tgt"] = ltp + tgt
                    status[t]["sl"] = ltp - tgt
                    status[t]["qty"] = 150
                    callReverse = False
                    sym = t
                    logging.info(f"call reversal put buy 2 lot in  {sym} at {ltp} tgt: {status[t]['tgt']} sl:{ status[t]['sl']}")

                if putReverse and i.endswith("CE"):
                    # order_place(access_token,150,t,"BUY")
                    oid = "order placement 2 lot"
                    status[t]["traded"] = "call"
                    status[t]["tgt"] = ltp + tgt
                    status[t]["sl"] = ltp - tgt
                    status[t]["qty"] = 150
                    putReverse = False
                    sym = t
                    logging.info(f"put reversal cal buy 2 lot in {sym} at {ltp} tgt: {status[t]['tgt']} sl: {status[t]['sl']}")

                if dt.datetime.now().time() >= dt.time(15, 25):
                    # order_place(access_token,status[sym]["qty"],sym,"SELL")
                    if status[sym]["qty"]:
                        logging.info(f"market close {sym} at {ltp} qty: {status[sym]['qty']}")
                    all_exit = True
                    break
                

            if all_exit == True :
                logging.info("all exit ..............................................................................")
                streamer.disconnect()
                break
        except Exception as e:
            traceback.print_exc()
            streamer.disconnect()
            break

except KeyboardInterrupt:
    streamer.disconnect()

