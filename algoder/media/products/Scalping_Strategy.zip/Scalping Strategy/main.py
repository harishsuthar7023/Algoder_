from utils.kiteapp import *
from utils.helper import *
import xlwings as xw

LOG_FILE = f'TRADE_LOG/{str(dt.date.today())}.log'
logging = logging_data(LOG_FILE)

userid = "AIL961"
LIVE_TRADING = False
trade_taken_today = False

today = str(dt.date.today())
enc = f"token_{today}.txt"

if enc not in os.listdir('utils'):
    tt = input("Enter the enc token: ")
    for i in os.listdir('utils'):
        if i.startswith("enc")  and i != enc:
            os.remove(f"utils/{i}")
            break
    with open(f'utils/{enc}', 'w') as f:
        f.write(tt)

with open(f"utils/{enc}","r") as file:
    token = file.read().strip()

kite = KiteApp("Kite", userid, token)
kws = kite.kws()

data_file = f"Data{today}.csv"
if data_file not in os.listdir('utils'):
    for i in os.listdir('utils'):
        if i.startswith("Data")  and i != data_file:
            os.remove(f"utils/{i}")
            break
    inst = pd.read_csv('https://api.kite.trade/instruments')
    data = inst[(inst['exchange'] == 'NFO') | (inst['exchange'] == 'BFO') | (inst['exchange'] == 'NSE')]
    inst.to_csv(f"utils/Data{today}.csv", index=False)
    print("Data Downloaded")
df = pd.read_csv(f'utils/{data_file}')

index = 'NIFTY'
strike = 24700
cepe = 'CE'
nearest_exp = 1
index_data1 = filter_data(df,index,strike,cepe,nearest_exp)

instrument_token = list(index_data1.keys())
trading_sym = list(index_data1.values())

ltp_data = {}

def on_ticks(ws, ticks):
    # print("Ticks: {}".format(ticks))
    try:
        for sym in ticks:
            ltp = sym['last_price']
            ltp_data[instrument_token[0]] = ltp
    except Exception as e:
        print("websocket error")

def on_connect(ws, response):
    global WS
    WS = ws
    ws.subscribe(instrument_token)
    ws.set_mode(ws.MODE_FULL, instrument_token)

def on_close(ws, code, reason):
    ws.stop()

kws.on_ticks = on_ticks
kws.on_connect = on_connect
kws.on_close = on_close
kws.connect(threaded=True)
sleep(3)

trade_via_excel_book = xw.Book('Algoder.xlsm')
sht = trade_via_excel_book.sheets("Algoder")

trade1,qty1 = int(sht.range('F8').value),int(sht.range('G8').value)
trade2,qty2 = int(sht.range('F9').value),int(sht.range('G9').value)
trade3,qty3 = int(sht.range('F10').value),int(sht.range('G10').value)
trade4,qty4 = int(sht.range('F11').value),int(sht.range('G11').value)
trade5,qty5 = int(sht.range('F12').value),int(sht.range('G12').value)
trade6,qty6 = int(sht.range('F13').value),int(sht.range('G13').value)
trade7,qty7 = int(sht.range('F14').value),int(sht.range('G14').value)
trade8,qty8 = int(sht.range('F15').value),int(sht.range('G15').value)

# print(trade1,qty1)

trades = {1:[trade1,qty1],2:[trade2,qty2],3:[trade3,qty3],4:[trade4,qty4],5:[trade5,qty5],6:[trade6,qty6],7:[trade7,qty7],8:[trade8,qty8]}

print(trades)
# sys.exit()
tgt = float(sht.range('F7').value)
sl = float(sht.range('F17').value)

index = [1,2,3,4,5,6,7,8]

status = {
    x: {
        "traded": None,
        "price": None,
        "qty": None,
        "sl": None,
        "tsl": None,
        "tgt": None,
        "diff": None,
        "lastTrade": None
    }
    for x in index
}

total_pnl = 0

if not os.path.exists("Algoder.xlsm"):
        print("'Algoder.xlsm' not exists")
        sys.exit()

while True:
    sleep(1)
    # print(ltp_data)
    ltp = ltp_data[instrument_token[0]]
    # ltp = ltp_batar['ltp']
    print(ltp)
    for i ,v in trades.items():
        if status[i]["traded"] == None:
            if ltp <= v[0]:
                status[i]["traded"] = True
                status[i]["price"] = ltp
                status[i]["sl"] = sl
                status[i]["tgt"] = ltp + tgt
                status[i]["qty"] = v[1]
                print(f"buy trade in {i} at {ltp} with qty {v[1]}")

        if status[i]["traded"] == True:
            if ltp >= status[i]["tgt"]:
                pnl = status[i]["qty"] * (ltp - status[i]["price"])
                total_pnl += pnl
                status[i]["traded"] = None
                print(f"Target hit in {i} at {ltp} with qty {v[1]} pnl {pnl} total_pnl {total_pnl}")
                sht.range('G18').value  = round(total_pnl,2)

            elif ltp <= status[i]["sl"]:
                pnl = status[i]["qty"] * (ltp - status[i]["price"])
                total_pnl += pnl
                print(f"Stoploss hit {i} at {ltp} pnl {pnl} total_pnl {total_pnl}")
                sht.range('G18').value  = round(total_pnl,2)
                status[i]["traded"] = None
                if all(v["traded"] is None for v in status.values()):
                    sys.exit()
                # sys.exit()
