
from time import sleep
import pandas as pd
import os
import sys
from concurrent.futures import ThreadPoolExecutor as TRD
import datetime as dt
from threading import Thread,Event
import logging
import pandas_ta as ta

def get_nth_nearest_expiry_row(df, n):
    df_sorted = df.sort_values(by="expiry").reset_index(drop=True)
    if n <= len(df_sorted):
        return df_sorted.iloc[[n - 1]]  # sirf nth row return hogi (1-based index)
    else:
        return pd.DataFrame()  # agar n jyada ho to empty DataFrame

def filter_data(df,index,strike,cepe,nearest_exp):
    data_dict = {}
    try:
        df = df[(df["name"] == index) & (df["segment"] == "NFO-OPT")]
        df = df[(df["strike"] == strike) & (df["instrument_type"] == cepe)]
        # df = df[df["expiry"] == min(df["expiry"])]
        df = get_nth_nearest_expiry_row(df, nearest_exp)

        # print(df)

        for i in df.index:
            symbol = df["tradingsymbol"][i]
            token =int(df["instrument_token"][i])
            data_dict[token] = symbol
        return data_dict
    except :
        data_dict = {}
        return data_dict




