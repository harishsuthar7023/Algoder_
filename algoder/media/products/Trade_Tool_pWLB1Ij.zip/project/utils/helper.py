import sys
import json
from PyQt6.QtWidgets import QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QGridLayout, QComboBox, QCheckBox, QLineEdit, QPushButton, QLabel, QSpacerItem, QSizePolicy, QStackedLayout, QFormLayout, QMessageBox,QToolButton,QFrame,QCompleter
from PyQt6.QtCore import Qt,QThread, pyqtSignal,QTimer, pyqtSlot
from PyQt6.QtGui import QIcon
from PIL import Image
import os
import pandas as pd
import datetime as dt
import pandas_ta as ta
import logging
import traceback
from concurrent.futures import ThreadPoolExecutor as TRD
from threading import Thread, Event

from time import sleep
from datetime import datetime, timedelta
import requests as rq
import json
from fyers_apiv3 import fyersModel
from fyers_apiv3.FyersWebsocket import order_ws,data_ws



class DataDownloaderThread(QThread):
    signal_stop = pyqtSignal()

    def __init__(self, symbol_list, interval, from_date, to_date, candle_data, fyers):
        super().__init__()
        self.symbol_list = symbol_list
        self.interval = interval
        self.from_date = from_date
        self.to_date = to_date
        self.candle_data = candle_data
        self.fyers = fyers
        self.event = Event()

    def get_candle_data(self, symbol, interval, from_date, to_date):
        data = {
            "symbol": symbol,
            "resolution": interval,
            "date_format": "1",
            "range_from": from_date,
            "range_to": to_date,
            "cont_flag": "1",
        }
        resp = self.fyers.history(data=data)
        df = pd.DataFrame(
            resp["candles"], columns=["date", "open", "high", "low", "close", "volume"]
        )
        df = df.reset_index()
        return df

    def run(self):
        try:
            while dt.datetime.now().time() <= dt.time(22, 30):
                if self.event.is_set():
                    print("Stop Data Downloader..")
                    break
                try:
                    if (dt.datetime.now().minute % self.interval == 0 and dt.datetime.now().second == 0) or not self.candle_data:
                        def data(symbol):
                            while not self.event.is_set():
                                try:
                                    df = self.get_candle_data(symbol, self.interval, self.from_date, self.to_date)
                                    self.candle_data[symbol] = df
                                    break
                                except Exception as e:
                                    sleep(1)
                                    print(f"Data Error {e}")

                        with TRD() as exc:
                            exc.map(data, self.symbol_list)
                        print("Data Downloaded ..........................")
                    sleep(1)
                except Exception as e:
                    print(f"Error occurred: {e}")
                    self.event.set()
                    break
        except Exception as e:
            print(f"Critical Error occurred: {e}")
            self.event.set()
        finally:
            self.signal_stop.emit()


class FyersUtilities():
    def __init__(self, fyers,fyers_web,perent):
        self.fyers = fyers
        self.fyers_web = fyers_web
        self.perent = perent
        self.status = {}
        # self.subscribe_symbol(['NSE:APOLLOHOSP-EQ'])


    @staticmethod
    def logging_data(LOG_FILE):
        logging.basicConfig(
            format="%(asctime)s %(message)s",
            datefmt="%H:%M:%S",
            level=logging.INFO,
            handlers=[logging.FileHandler(LOG_FILE, "a"), logging.StreamHandler()],
        )
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)
        return logger

    def subscribe_symbol(self,data):
        data_type = "SymbolUpdate"
        self.fyers_web.subscribe(symbols=data, data_type=data_type)

    def download_instruments(self):
        today = str(dt.date.today())
        filename = f"Data_{today}.csv"

        if filename not in os.listdir("utils"):
            for i in os.listdir("utils"):
                if i.startswith("Data") and i.endswith(".csv") and i != filename:
                    os.remove(f"utils/{i}")
                    # print("yes")

        if filename not in os.listdir("utils"):
            names = (
                "Fytoken",
                "Symbol Details",
                "Exchange Instrument type",
                "Minimum lot size",
                "Tick size",
                "ISIN",
                "Trading Session",
                "Last update date",
                "Expiry date",
                "Symbol ticker",
                "Exchange",
                "Segment",
                "Scrip code",
                "Underlying symbol",
                "Underlying scrip code",
                "Strike price",
                "Option type",
                "Underlying FyToken",
                "Reserved column",
                "Reserved column",
                "Reserved column",
            )

            print("Data Downloading..")

            for i in os.listdir("utils"):
                # if filename.startswith('Data_') and filename.endswith('.csv'):
                #     os.remove(f"utils/{i}")
                #     print("File Deleted")
                fileUrl = "https://public.fyers.in/sym_details/NSE_FO.csv"
                fileUrl2 = "https://public.fyers.in/sym_details/BSE_FO.csv"

                inst1 = pd.read_csv(fileUrl)
                inst2 = pd.read_csv(fileUrl2)
                inst1.columns = names
                inst2.columns = names

                inst = pd.concat([inst1, inst2], ignore_index=True)

                inst.to_csv(f"utils/{filename}")
                break


    def ltp_symbols(self, df, index, lot_size):
        df = df[df["Minimum lot size"] == lot_size].copy()
        df = df[df["Underlying symbol"] == index]
        df["Expiry date"] = df["Expiry date"].apply(
            lambda x: dt.datetime.fromtimestamp(int(x)).date()
        )
        expiry = min(df["Expiry date"].unique())
        df = df[df["Expiry date"] == expiry]
        ltp_sym = df["Symbol ticker"].to_list()
        return ltp_sym

    def filter_data(self, df, lot_size, index, atm_strike, otm):
        df = df[df["Minimum lot size"] == lot_size].copy()
        df = df[df["Underlying symbol"] == index]
        df["Expiry date"] = df["Expiry date"].apply(lambda x: dt.datetime.fromtimestamp(int(x)).date())
        expiry = min(df["Expiry date"].unique())
        df = df[df["Expiry date"] == expiry]
        if "Unnamed: 0" in df.columns:
            df = df.drop("Unnamed: 0", axis=1)
        df = df[(df["Strike price"] >= atm_strike - otm * 100) & (df["Strike price"] <= atm_strike + otm * 100)]
        top_pe = df[df["Option type"] == "CE"].nlargest(1, "Strike price")
        bottom_ce = df[df["Option type"] == "PE"].nsmallest(1, "Strike price")
        result = pd.concat([top_pe, bottom_ce])
        return result[["Symbol ticker", "Strike price", "Option type"]]


    def get_candle_data(self, symbol, interval, from_date, to_date):
        data = {
            "symbol": symbol,
            "resolution": interval,
            "date_format": "1",
            "range_from": from_date,
            "range_to": to_date,
            "cont_flag": "1",
        }
        resp = self.fyers.history(data=data)
        df = pd.DataFrame(
            resp["candles"], columns=["date", "open", "high", "low", "close", "volume"]
        )
        df = df.reset_index()
        return df

    def data_downloader(self, event, symbol_list, interval, from_date, to_date, candle_data):
        try:
            while dt.datetime.now().time() <= dt.time(22, 30):
                if event.is_set():
                    print("Stop Data Downloader..")
                    break
                try:
                    if (dt.datetime.now().minute % interval == 0 and dt.datetime.now().second == 0) or not candle_data:
                        def data(symbol):
                            while not event.is_set():
                                try:
                                    df = self.get_candle_data( symbol, interval, from_date, to_date)
                                    candle_data[symbol] = df
                                    break
                                except Exception as e:
                                    sleep(1)
                                    print(f"Data Error {e}")

                        with TRD() as exc:
                            exc.map(data, symbol_list)
                        print("Data Downloaded ..........................")
                    sleep(1)
                except Exception as e:
                    print(f"Error occurred: {e}")
                    event.set()
                    break
        except Exception as e:
            print(f"Critical Error occurred: {e}")
            event.set()
        finally:
            self.on_data_downloader_stopped()

    def data_downloader(self, event, symbol_list, interval, from_date, to_date, candle_data):
        error_flag = False

        while dt.datetime.now().time() <= dt.time(22, 30):
            sleep(1)
            if event.is_set() or error_flag:
                print("Stop Data Downloader..")
                break
            if (dt.datetime.now().minute % interval == 0 and dt.datetime.now().second == 0) or not candle_data:

                def data(symbol):
                    nonlocal error_flag
                    while True:
                        try:
                            df = self.get_candle_data(
                                symbol, interval, from_date, to_date)
                            candle_data[symbol] = df
                            break
                        except Exception as e:
                            sleep(1)
                            error_flag = True
                            break

                with TRD() as exc:
                    exc.map(data, symbol_list)
                if error_flag:
                    break
                print("Data Downloaded ..........................")

    def placeOrder(self, symbol, qty, side,type,price):
        data = {
            "symbol": symbol,
            "qty": qty,
            "type": type,
            "side": side,
            "productType": "INTRADAY",
            "limitPrice": price,
            "stopPrice": 0,
            "validity": "DAY",
            "disclosedQty": 0,
            "offlineOrder": False,
        }
        return self.fyers.place_order(data=data)

        # return

    def get_atm_value(self, ltp, gap):
        return 100 * round(ltp / gap)

    def index_atm(self, index):
        if index == "BANKNIFTY":
            index = "NIFTYBANK"
            data = {"symbols": f"NSE:{index}-INDEX"}
        elif index == "NIFTY":
            index = "NIFTY50"
            data = {"symbols": f"NSE:{index}-INDEX"}
        elif index == ("BANKEX" or "SENSEX"):
            data = {"symbols": f"BSE:{index}-INDEX"}
        else:
            data = {"symbols": f"NSE:{index}-INDEX"}

        response = self.fyers.quotes(data=data)
        ltp = response["d"][0]["v"]["lp"]
        atm = 100 * round(ltp / 100)
        return atm

    def getSymbol(self, df, strike, cepe):
        return df[(df["StrikePrice"] == strike) & (df["OptionType"] == cepe)][
            "TradingSymbol"
        ].iloc[0]

    def index_expiry(self,df,index):
        df = df[df["Segment"] == 11]
        df = df[df["Underlying symbol"] == index]
        df["Expiry date"] = df["Expiry date"].apply(lambda x: dt.datetime.fromtimestamp(int(x)).date())
        exp = sorted(set(df['Expiry date']))[:4]
        date_str_list = [d.strftime('%Y-%m-%d') for d in exp]
        return date_str_list


    def stock_symbol(self,df):
        df = df[df["Segment"] == 11]
        df = df[df["Exchange Instrument type"] == 13]
        df["Expiry date"] = df["Expiry date"].apply(lambda x: dt.datetime.fromtimestamp(int(x)).date())
        df_unique = df.drop_duplicates(subset='Underlying symbol', keep='first')
        symbol = []
        for i in df_unique.index:
            sym = df['Underlying symbol'][i]
            symbol.append(sym)
        return symbol

    def stock_expiry(self,df):
        df = df[df["Segment"] == 11]
        df = df[df["Exchange Instrument type"] == 13]
        df = df[df["Underlying symbol"] == 'AARTIIND']
        df["Expiry date"] = df["Expiry date"].apply(lambda x: dt.datetime.fromtimestamp(int(x)).date())
        exp = sorted(set(df['Expiry date']))[:4]
        date_str_list = [d.strftime('%Y-%m-%d') for d in exp]
        return date_str_list

    def index_strike(self,df,index,atm):
        df = df[df["Segment"] == 11]
        df = df[df['Underlying symbol'] == index]
        df["Expiry date"] = df["Expiry date"].apply(lambda x: dt.datetime.fromtimestamp(int(x)).date())
        df = df[df["Expiry date"] == min(df["Expiry date"])]
        if index == "BANKNIFTY":
            gap_value = 100
        if index == "NIFTY":
            gap_value = 50
        if index == "FINNIFTY":
            gap_value = 50
        if index == "MIDCPNIFTY":
            gap_value = 25
        if index == "BANKEX":
            gap_value = 100
        if index == "SENSEX":
            gap_value = 100
        df = df[(df['Strike price'] >= atm-(gap_value*8)) &( df['Strike price'] <= atm+(gap_value*8))]
        data = {}

        strike = df["Strike price"].tolist()
        unique_list = list(set(strike))

# Sorting the list to maintain order
        unique_list.sort()

        return unique_list

    def index_symbol(self,df,index,strike,cepe):
        df = df[df["Segment"] == 11]
        df = df[df['Underlying symbol'] == index]
        df = df[df['Strike price'] == strike]
        df = df[df['Option type'] == cepe]
        df["Expiry date"] = df["Expiry date"].apply(lambda x: dt.datetime.fromtimestamp(int(x)).date())
        df = df[df["Expiry date"] == min(df["Expiry date"])]
        symbol = df["Symbol ticker"].tolist()
        return symbol

    def future_symbol(self,df,sym):
        df = df[df["Segment"] == 11]
        df = df[df["Exchange Instrument type"] == 13]
        df = df[df["Expiry date"] == min(df["Expiry date"])]
        df = df[df['Underlying symbol'] == sym]
        symbol = df["Symbol ticker"].tolist()
        return symbol

    def lot_size(self,df,sym):
        df = df[df["Segment"] == 11]
        df = df[df['Symbol ticker'] == sym]
        lot = df["Minimum lot size"].tolist()
        return lot


    def get_data_downloader(self,symbol_list,intervala_cb):

        interval = int(intervala_cb.currentText())
        from_date = (dt.datetime.now() - dt.timedelta(days=5)).date()
        to_date = dt.datetime.now().date()
        self.event = Event()
        self.candle_data = {}
        self.event.clear()

        self.data_downloader_thread = Thread(
            target=self.data_downloader,args=(self.event, symbol_list, interval, from_date, to_date, self.candle_data))
        self.data_downloader_thread.start()

        # sleep(5)
        # print(self.candle_data)




    def break_out_entry(self,name_cb,quantity_le,lot_le,df,perent,status,ltp_data,percent_cb,point_cb,percent_cb2,point_cb2,target_le,stoploss_le,index_cb3,strike_cb2,index_cb4,strike_cb3,abo_bolw_input_le,index_cb2,strike_cb,above_cb,below_cb,index_cb,buy_cb,sell_cb,close_cb,Deviation,limit_cb,stoploss_cb,target_cb,lot_cb,market_cb,lvl_price_cb,avg_price_cb,order_data,strike_le2,same_strike_cb,ce_cb2,pe_cb2,ce_cb,pe_cb):

        if stoploss_cb.isChecked() and not lvl_price_cb.isChecked() and not avg_price_cb.isChecked() and not index_cb3.isChecked() and not strike_cb2.isChecked():
            QMessageBox.critical(self.perent, "Input Error", "Please ensure stoploss index/strike Box are Checked correctly.")
            return

        if target_cb.isChecked() and not lvl_price_cb.isChecked() and not avg_price_cb.isChecked() and not index_cb4.isChecked() and not strike_cb3.isChecked():
            QMessageBox.critical(self.perent, "Input Error", "Please ensure stoploss index/strike Box are Checked correctly.")
            return

        if stoploss_cb.isChecked() and not percent_cb.isChecked() and not point_cb.isChecked() or stoploss_le.text().strip() == '':
            QMessageBox.critical(self.perent, "Input Error", "Please ensure stoploss % / point Box and input are Checked correctly.")
            return

        if target_cb.isChecked() and not percent_cb2.isChecked() and not point_cb2.isChecked() or target_le.text().strip() == '':
            QMessageBox.critical(self.perent, "Input Error", "Please ensure target % / point Box and input are Checked correctly.")
            return

        if (strike_cb.isChecked() or index_cb2.isChecked()) and abo_bolw_input_le.text().strip() == '':
            QMessageBox.critical(self.perent, "Input Error", "Please ensure Center Box is Empty !.")
            return

        if lvl_price_cb.isChecked() and not index_cb2.isChecked() and not strike_cb.isChecked() or abo_bolw_input_le.text().strip() == '' :
            QMessageBox.critical(self.perent, "Input Error", "Please ensure Center Box is Empty !.")
            return




        if not ce_cb.isChecked() and not pe_cb.isChecked():
            QMessageBox.critical(self.perent, "Input Error", "Please ensure BUY/SELL Box are Checked correctly.")
            # self.show_message()
            return

        if not buy_cb.isChecked() and not sell_cb.isChecked():
            QMessageBox.critical(self.perent, "Input Error", "Please ensure BUY/SELL Box are Checked correctly.")
            # self.show_message()
            return

        if not limit_cb.isChecked() and not market_cb.isChecked():
            QMessageBox.critical(self.perent, "Input Error", "Please ensure BUY/SELL Box are Checked correctly.")
            # self.show_message()
            return

        if not lot_cb.isChecked() and not quantity_le.isChecked():
            QMessageBox.critical(self.perent, "Input Error", "Please ensure QTY/LOT are Checked correctly.")
            # self.show_message()
            return

        if lot_le.text().strip() == '':
            QMessageBox.critical(self.perent, "Input Error", "Please ensure QTY/LOT input Box are fill correctly.")
                    # self.show_message()
            return


        line = 0
        while True:
            try:
                if line == 0:
                    sleep(3)
                sleep(1)
                if index_cb2.isChecked():
                    ltp = ltp_data[status["ltp_symbol"]]

                elif strike_cb.isChecked():
                    ltp = ltp_data[status["symbol"]]

                if close_cb.isChecked() and index_cb2.isChecked():
                    dff = self.candle_data[status["ltp_symbol"]]
                    close = dff.iloc[-2]["close"]

                elif close_cb.isChecked() and strike_cb.isChecked():
                    dff = self.candle_data[status["symbol"]]
                    close = dff.iloc[-2]["close"]

                if close_cb.isChecked() and above_cb.isChecked() or close_cb.isChecked() and below_cb.isChecked():
                    if buy_cb.isChecked():
                        if close > float(abo_bolw_input_le.text()) and close < dev:
                            dev = float(abo_bolw_input_le.text())+(float(abo_bolw_input_le.text())*(float(Deviation.text())/100))
                            # print(ltp)
                            line = 1
                            if above_cb.isChecked() and ltp >= float(abo_bolw_input_le.text()):
                                if index_cb.isChecked() :
                                    self.index_ord(strike_le2,name_cb,quantity_le,lot_le,df,perent,status,ltp_data,percent_cb,point_cb,percent_cb2,point_cb2,target_le,stoploss_le,index_cb3,strike_cb2,index_cb4,strike_cb3,limit_cb,stoploss_cb,target_cb,lot_cb,market_cb,lvl_price_cb,abo_bolw_input_le,avg_price_cb,order_data,buy_cb,sell_cb,same_strike_cb,ce_cb2,pe_cb2,ce_cb,pe_cb,index_cb2,strike_cb)
                                    print("above entry")

                                break
                            elif below_cb.isChecked() and ltp <= float(abo_bolw_input_le.text()):
                                if index_cb.isChecked():
                                    self.index_ord(strike_le2,name_cb,quantity_le,lot_le,df,perent,status,ltp_data,percent_cb,point_cb,percent_cb2,point_cb2,target_le,stoploss_le,index_cb3,strike_cb2,index_cb4,strike_cb3,limit_cb,stoploss_cb,target_cb,lot_cb,market_cb,lvl_price_cb,abo_bolw_input_le,avg_price_cb,order_data,buy_cb,sell_cb,same_strike_cb,ce_cb2,pe_cb2,ce_cb,pe_cb,index_cb2,strike_cb)
                                break
                    elif sell_cb.isChecked():
                        if close < float(abo_bolw_input_le.text()) and close > dev:
                            dev = float(abo_bolw_input_le.text())-(float(abo_bolw_input_le.text())*(float(Deviation.text())/100))
                            # print(ltp)
                            line = 1
                            if above_cb.isChecked() and ltp <= float(abo_bolw_input_le.text()):
                                if index_cb.isChecked() :
                                    self.index_ord(strike_le2,name_cb,quantity_le,lot_le,df,perent,status,ltp_data,percent_cb,point_cb,percent_cb2,point_cb2,target_le,stoploss_le,index_cb3,strike_cb2,index_cb4,strike_cb3,limit_cb,stoploss_cb,target_cb,lot_cb,market_cb,lvl_price_cb,abo_bolw_input_le,avg_price_cb,order_data,buy_cb,sell_cb,same_strike_cb,ce_cb2,pe_cb2,ce_cb,pe_cb,index_cb2,strike_cb)
                                    print("above entry")

                                break
                            elif below_cb.isChecked() and ltp >= float(abo_bolw_input_le.text()):
                                if index_cb.isChecked():
                                    self.index_ord(strike_le2,name_cb,quantity_le,lot_le,df,perent,status,ltp_data,percent_cb,point_cb,percent_cb2,point_cb2,target_le,stoploss_le,index_cb3,strike_cb2,index_cb4,strike_cb3,limit_cb,stoploss_cb,target_cb,lot_cb,market_cb,lvl_price_cb,abo_bolw_input_le,avg_price_cb,order_data,buy_cb,sell_cb,same_strike_cb,ce_cb2,pe_cb2,ce_cb,pe_cb,index_cb2,strike_cb)
                                break

                elif buy_cb.isChecked():
                    if above_cb.isChecked() and ltp >= float(abo_bolw_input_le.text()):
                        if index_cb.isChecked() :
                            self.index_ord(strike_le2,name_cb,quantity_le,lot_le,df,perent,status,ltp_data,percent_cb,point_cb,percent_cb2,point_cb2,target_le,stoploss_le,index_cb3,strike_cb2,index_cb4,strike_cb3,limit_cb,stoploss_cb,target_cb,lot_cb,market_cb,lvl_price_cb,abo_bolw_input_le,avg_price_cb,order_data,buy_cb,sell_cb,same_strike_cb,ce_cb2,pe_cb2,ce_cb,pe_cb,index_cb2,strike_cb)
                            break

                    elif below_cb.isChecked() and ltp <= float(abo_bolw_input_le.text()):
                        if index_cb.isChecked():
                            self.index_ord(strike_le2,name_cb,quantity_le,lot_le,df,perent,status,ltp_data,percent_cb,point_cb,percent_cb2,point_cb2,target_le,stoploss_le,index_cb3,strike_cb2,index_cb4,strike_cb3,limit_cb,stoploss_cb,target_cb,lot_cb,market_cb,lvl_price_cb,abo_bolw_input_le,avg_price_cb,order_data,buy_cb,sell_cb,same_strike_cb,ce_cb2,pe_cb2,ce_cb,pe_cb,index_cb2,strike_cb)
                            break

                elif sell_cb.isChecked():
                    if above_cb.isChecked() and ltp <= float(abo_bolw_input_le.text()):
                        if index_cb.isChecked() :
                            self.index_ord(strike_le2,name_cb,quantity_le,lot_le,df,perent,status,ltp_data,percent_cb,point_cb,percent_cb2,point_cb2,target_le,stoploss_le,index_cb3,strike_cb2,index_cb4,strike_cb3,limit_cb,stoploss_cb,target_cb,lot_cb,market_cb,lvl_price_cb,abo_bolw_input_le,avg_price_cb,order_data,buy_cb,sell_cb,same_strike_cb,ce_cb2,pe_cb2,ce_cb,pe_cb,index_cb2,strike_cb)
                            break

                    elif below_cb.isChecked() and ltp >= float(abo_bolw_input_le.text()):
                        if index_cb.isChecked():
                            self.index_ord(strike_le2,name_cb,quantity_le,lot_le,df,perent,status,ltp_data,percent_cb,point_cb,percent_cb2,point_cb2,target_le,stoploss_le,index_cb3,strike_cb2,index_cb4,strike_cb3,limit_cb,stoploss_cb,target_cb,lot_cb,market_cb,lvl_price_cb,abo_bolw_input_le,avg_price_cb,order_data,buy_cb,sell_cb,same_strike_cb,ce_cb2,pe_cb2,ce_cb,pe_cb,index_cb2,strike_cb)
                            break


                elif close_cb.isChecked():
                    if buy_cb.isChecked():
                        if close > float(abo_bolw_input_le.text()) and close < dev :
                            dev = float(abo_bolw_input_le.text())+(float(abo_bolw_input_le.text())*(float(Deviation.text())/100))
                            self.index_ord(strike_le2,name_cb,quantity_le,lot_le,df,perent,status,ltp_data,percent_cb,point_cb,percent_cb2,point_cb2,target_le,stoploss_le,index_cb3,strike_cb2,index_cb4,strike_cb3,limit_cb,stoploss_cb,target_cb,lot_cb,market_cb,lvl_price_cb,abo_bolw_input_le,avg_price_cb,order_data,buy_cb,sell_cb,same_strike_cb,ce_cb2,pe_cb2,ce_cb,pe_cb,index_cb2,strike_cb)
                            break
                    elif sell_cb.isChecked():
                        if close < float(abo_bolw_input_le.text()) and close > dev :
                            dev = float(abo_bolw_input_le.text())-(float(abo_bolw_input_le.text())*(float(Deviation.text())/100))
                            self.index_ord(strike_le2,name_cb,quantity_le,lot_le,df,perent,status,ltp_data,percent_cb,point_cb,percent_cb2,point_cb2,target_le,stoploss_le,index_cb3,strike_cb2,index_cb4,strike_cb3,limit_cb,stoploss_cb,target_cb,lot_cb,market_cb,lvl_price_cb,abo_bolw_input_le,avg_price_cb,order_data,buy_cb,sell_cb,same_strike_cb,ce_cb2,pe_cb2,ce_cb,pe_cb,index_cb2,strike_cb)
                            break

                # if close > float(abo_bolw_input_le.text()) and close > dev:
                elif close_cb.isChecked() and close > dev and buy_cb.isChecked():
                    print("Input Error", "Please ensure all inputs are filled correctly.")
                    break
                elif close_cb.isChecked() and close < dev and sell_cb.isChecked():
                    print("Input Error", "Please ensure all inputs are filled correctly.")
                    break
            except:
                print("error in break_out entry function ")
                traceback.print_exc()
        print("while break")
        if close_cb.isChecked():
            self.stop_data_downloader()


    def stop_data_downloader(self):
        if self.data_downloader_thread:
            self.event.set()
            self.data_downloader_thread.join()

    @pyqtSlot()
    def on_data_downloader_stopped(self):
        print("Data downloader thread has stopped.")
        self.data_downloader_thread = None


    def show_message(self,status):
            self.message_box = QMessageBox(QMessageBox.Icon.Critical, "Order Placed", f"Your order is Placed Succesfully in {status["symbol"]}.", parent=self.perent)
            self.message_box.setStandardButtons(QMessageBox.StandardButton.NoButton)
            self.message_box.show()

            # Set a timer to close the message box after 2 seconds (2000 milliseconds)
            QTimer.singleShot(4000, self.message_box.accept)

    def index_ord(self,strike_le2,name_cb,quantity_le,lot_le,df,perent,status,ltp_data,percent_cb,point_cb,percent_cb2,point_cb2,target_le,stoploss_le,index_cb3,strike_cb2,index_cb4,strike_cb3,limit_cb,stoploss_cb,target_cb,lot_cb,market_cb,lvl_price_cb,abo_bolw_input_le,avg_price_cb,order_data,buy_cb,sell_cb,same_strike_cb,ce_cb2,pe_cb2,ce_cb,pe_cb,index_cb2,strike_cb):
        try:

            if stoploss_cb.isChecked() and not lvl_price_cb.isChecked() and not avg_price_cb.isChecked() and not index_cb3.isChecked() and not strike_cb2.isChecked():
                QMessageBox.critical(self.perent, "Input Error", "Please ensure stoploss index/strike Box are Checked correctly.")
                return

            if target_cb.isChecked() and not lvl_price_cb.isChecked() and not avg_price_cb.isChecked() and not index_cb4.isChecked() and not strike_cb3.isChecked():
                QMessageBox.critical(self.perent, "Input Error", "Please ensure target index/strike Box are Checked correctly.")
                return

            if stoploss_cb.isChecked() and not percent_cb.isChecked() and not point_cb.isChecked() or stoploss_le.text().strip() == '':
                QMessageBox.critical(self.perent, "Input Error", "Please ensure stoploss % / point Box and input are Checked correctly.")
                return

            if target_cb.isChecked() and not percent_cb2.isChecked() and not point_cb2.isChecked() or target_le.text().strip() == '':
                QMessageBox.critical(self.perent, "Input Error", "Please ensure target % / point Box and input are Checked correctly.")
                return

            if not ce_cb.isChecked() and not pe_cb.isChecked():
                QMessageBox.critical(self.perent, "Input Error", "Please ensure BUY/SELL Box are Checked correctly.")
                # self.show_message()
                return

            if not buy_cb.isChecked() and not sell_cb.isChecked():
                QMessageBox.critical(self.perent, "Input Error", "Please ensure BUY/SELL Box are Checked correctly.")
                # self.show_message()
                return

            if lvl_price_cb.isChecked() and not index_cb2.isChecked() and not strike_cb.isChecked() or abo_bolw_input_le.text().strip() == '' :
                QMessageBox.critical(self.perent, "Input Error", "Please ensure Center Box is Empty !.")
                return
            elif buy_cb.isChecked():
                side = 1
            elif sell_cb.isChecked():
                side = -1

            try:
                if not quantity_le.isChecked() and not lot_cb.isChecked():
                    QMessageBox.critical(self.perent, "Input Error", "Please ensure QTY/LOT Box are Checked correctly.")
                    return

                elif quantity_le.isChecked():
                    qty = int(lot_le.text())
                elif lot_cb.isChecked():
                    lot = self.lot_size(df,status["symbol"])
                    qty = int(lot_le.text())*int(lot[0])
            except:
                QMessageBox.critical(self.perent, "Input Error", "Please ensure QTY/Lot inputs are filled correctly.")
                return
            try:
                if not limit_cb.isChecked() and not market_cb.isChecked():
                    QMessageBox.critical(self.perent, "Input Error", "Please ensure LIMIT/MARKET Box are Checked correctly.")
                    return
                elif limit_cb.isChecked():
                    typ = 1
                    sleep(0.3)
                    self.placeOrder(status["symbol"], qty, side,typ,ltp_data[status["symbol"]])
                elif market_cb.isChecked():
                    typ = 2
                    self.placeOrder(status["symbol"], qty, side,typ,0)
                print("ORDER PLACED")
                self.show_message(status)
            except:
                QMessageBox.critical(self.perent, "Input Error", f"Please ensure all inputs are filled correctly.")
                return

            if side == 1:
                sd = "Buy"
            else:
                sd = "Sell"
            status["traded"] = sd

            if avg_price_cb.isChecked() and stoploss_cb.isChecked() and target_cb.isChecked():
                sleep(1)
                ltp = order_data[status["symbol"]]["price"]
                status["price"] = ltp

                if sd == "Sell":
                    if percent_cb.isChecked() and stoploss_le.text().strip() != '':
                        status["sl"] = ltp*(1+float(stoploss_le.text())/100)
                    elif point_cb.isChecked() and stoploss_le.text().strip() != '':
                        status['sl'] = ltp + float(stoploss_le.text())

                    if percent_cb2.isChecked() and target_le.text().strip() != '':
                        status["tgt"] = ltp*(1-float(target_le.text())/100)
                    elif point_cb2.isChecked() and target_le.text().strip() != '':
                        status['tgt'] = ltp - float(target_le.text())
                else:
                    if percent_cb.isChecked() and stoploss_le.text().strip() != '':
                        status["sl"] = ltp*(1-float(stoploss_le.text())/100)
                    elif point_cb.isChecked() and stoploss_le.text().strip() != '':
                        status['sl'] = ltp - float(stoploss_le.text())

                    if percent_cb2.isChecked() and target_le.text().strip() != '':
                        status["tgt"] = ltp*(1+float(target_le.text())/100)
                    elif point_cb2.isChecked() and target_le.text().strip() != '':
                        status['tgt'] = ltp + float(target_le.text())


            elif lvl_price_cb.isChecked() and abo_bolw_input_le.text().strip() != '' and stoploss_cb.isChecked() and target_cb.isChecked():
                ltp = float(abo_bolw_input_le.text())
                status["price"] = ltp
                if sd == "Sell":
                    if percent_cb.isChecked()and stoploss_le.text().strip() != '':
                        status["sl"] = ltp*(1+float(stoploss_le.text())/100)
                    elif point_cb.isChecked()and stoploss_le.text().strip() != '':
                        status['sl'] = ltp + float(stoploss_le.text())

                    if percent_cb2.isChecked()and target_le.text().strip() != '':
                        status["tgt"] = ltp*(1-float(target_le.text())/100)
                    elif point_cb2.isChecked()and target_le.text().strip() != '':
                        status['tgt'] = ltp - float(target_le.text())
                else:
                    if percent_cb.isChecked()and stoploss_le.text().strip() != '':
                        status["sl"] = ltp*(1-float(stoploss_le.text())/100)
                    elif point_cb.isChecked()and stoploss_le.text().strip() != '':
                        status['sl'] = ltp - float(stoploss_le.text())

                    if percent_cb2.isChecked() and target_le.text().strip() != '':
                        status["tgt"] = ltp*(1+float(target_le.text())/100)
                    elif point_cb2.isChecked() and target_le.text().strip() != '':
                        status['tgt'] = ltp + float(target_le.text())

            elif stoploss_cb.isChecked() and not lvl_price_cb.isChecked() and not avg_price_cb.isChecked():
                if index_cb3.isChecked():
                    ltp = ltp_data[status["ltp_symbol"]]
                    status["price"] = ltp

                elif strike_cb2.isChecked():
                    if same_strike_cb.isChecked():
                        ltp = ltp_data[status["symbol"]]
                        status["price"] = ltp
                    elif ce_cb2.isChecked():
                        strk = float(strike_le2.currentText())
                        symbol = self.index_symbol(df,name_cb.currentText(),strk,"CE")
                        self.subscribe_symbol(symbol)
                        # sleep(0.3)
                        ltp = ltp_data[symbol[0]]
                        status["price"] = ltp
                    elif pe_cb2.isChecked():
                        strk = float(strike_le2.currentText())
                        symbol = self.index_symbol(df,name_cb.currentText(),strk,"PE")
                        self.subscribe_symbol(symbol)
                        ltp = ltp_data[symbol[0]]
                        status["price"] = ltp

                if sd == "Sell":
                    if percent_cb.isChecked() and stoploss_le.text().strip() != '':
                        status["sl"] = ltp*(1+float(stoploss_le.text())/100)
                    elif point_cb.isChecked() and stoploss_le.text().strip() != '':
                        status['sl'] = ltp + float(stoploss_le.text())
                else:
                    if percent_cb.isChecked() and stoploss_le.text().strip() != '':
                        status["sl"] = ltp*(1-float(stoploss_le.text())/100)
                    elif point_cb.isChecked() and stoploss_le.text().strip() != '':
                        status['sl'] = ltp - float(stoploss_le.text())

            if target_cb.isChecked() and not lvl_price_cb.isChecked() and not avg_price_cb.isChecked():
                if index_cb4.isChecked():
                    ltp2 = ltp_data[status["ltp_symbol"]]
                    status["price"] = ltp2

                elif strike_cb3.isChecked():
                    if same_strike_cb.isChecked():
                        ltp2 = ltp_data[status["symbol"]]
                        status["price"] = ltp2
                    elif ce_cb2.isChecked():
                        strk = float(strike_le2.currentText())
                        symbol = self.index_symbol(df,name_cb.currentText(),strk,"CE")
                        ltp2 = ltp_data[symbol[0]]
                        status["price"] = ltp2
                    elif pe_cb2.isChecked():
                        strk = float(strike_le2.currentText())
                        symbol = self.index_symbol(df,name_cb.currentText(),strk,"PE")
                        ltp2 = ltp_data[symbol[0]]
                        status["price"] = ltp2

                if sd == "Sell":
                    if percent_cb2.isChecked() and target_le.text().strip() != '':
                        status["tgt"] = ltp2*(1-float(target_le.text())/100)
                    elif point_cb2.isChecked() and target_le.text().strip() != '':
                        status['tgt'] = ltp2 - float(target_le.text())
                else :
                    if percent_cb2.isChecked() and target_le.text().strip() != '':
                        status["tgt"] = ltp2*(1+float(target_le.text())/100)
                    elif point_cb2.isChecked() and target_le.text().strip() != '':
                        status['tgt'] = ltp2 + float(target_le.text())

        except:
            print("Please ensure all inputs are filled correctly.")
            traceback.print_exc()
            QMessageBox.critical(self.perent, "Input Error", "Please ensure all inputs are filled correctly.")

    def future_ord(self,side,name_cb,quantity_le,lot_le,df,perent,status,ltp_data,percent_cb,point_cb,percent_cb2,point_cb2,target_le,stoploss_le,lot_cb):
        try:
            if side == 1:
                sd = "Buy"
            else:
                sd = "Sell"

            # symbol = self.future_symbol(df,name_cb.currentText())
            # print(status["symbol"])

            if quantity_le.isChecked():
                qty = int(lot_le.text())
                # print(qty)
            elif lot_cb.isChecked():
                # print(df)
                lot = self.lot_size(df,status["symbol"][0])
                # print(lot)
                qty = int(lot_le.text())*int(lot[0])
                # print(qty)

            self.placeOrder(status["symbol"][0], qty, side)

            ltp = ltp_data[status["symbol"][0]]
            print(ltp)

            status["traded"] = sd
            # status["symbol"] = symbol[0]
            status["price"] = ltp
            if percent_cb.isChecked():
                status["sl"] = ltp*(1-stoploss_le/100)
            elif point_cb.isChecked():
                status['sl'] = ltp - stoploss_le

            if percent_cb2.isChecked():
                status["tgt"] = ltp*(1+target_le/100)
            elif point_cb2.isChecked():
                status['tgt'] = ltp + target_le

            print(f"order placed : {status["symbol"][0]}")
        except:
            # traceback.print_exc()
            # print("Input Error", "Please ensure all inputs are filled correctly.")
            QMessageBox.critical(perent, "Input Error", "Please ensure all inputs are filled correctly.")

    def ind_ltp_data_symbol(self,strike_le,ce_cb,pe_cb,df,name_cb,index_cb,future_cb):
        if index_cb.isChecked():
            strk = float(strike_le.currentText())
            # print(strk)
            if ce_cb.isChecked():
                symbol = self.index_symbol(df,name_cb.currentText(),strk,'CE')
            elif pe_cb.isChecked():
                symbol = self.index_symbol(df,name_cb.currentText(),strk,'PE')

        elif future_cb.isChecked():
            symbol = self.future_symbol(df,name_cb.currentText())
            print(symbol)

        print(symbol)
        return symbol
