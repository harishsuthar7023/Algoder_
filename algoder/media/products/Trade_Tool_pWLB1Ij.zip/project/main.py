
from utils.helper import *
from Login.login import *
import traceback
import threading

# img = Image.open('Layer 1.png')
# # Save the image without the ICC profile
# img.save('Layer 1_fixed.png', icc_profile=None)

class MainWindows(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ltp_data = {}
        self.fyers_od = None
        self.fyers_web = None
        self.ws_connect = False
        self.order_data = {}
        self.status = {}

        self.setWindowTitle("Trade Tool")
        self.setGeometry(600, 70, 680, 550)
        self.setWindowIcon(QIcon('assets/Layer 1_fixed.png'))
        # self.main_stretegy = Main_Strategy()
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # Main layout
        main_layout = QVBoxLayout()
        central_widget.setLayout(main_layout)

        # Top navigation layout
        nav_layout = QHBoxLayout()
        main_layout.addLayout(nav_layout)

        # Stack layout for different frames
        self.stack_layout = QStackedLayout()
        main_layout.addLayout(self.stack_layout)

        # Buttons for top navigation
        button1 = QPushButton("Trade")
        button2 = QPushButton("Lite")
        button3 = QPushButton("Position")
        button4 = QPushButton("Login")

        nav_layout.addWidget(button1)
        nav_layout.addWidget(button2)
        nav_layout.addWidget(button3)
        nav_layout.addWidget(button4)

        # Connect buttons to their respective frames
        button1.clicked.connect(lambda: self.display_frame(0))
        button2.clicked.connect(lambda: self.display_frame(1))
        button3.clicked.connect(lambda: self.display_frame(2))
        button4.clicked.connect(lambda: self.display_frame(3))

        # Create frames
        with open(f"json/login_data.json", "r") as f:
            Cread = json.load(f)

        self.fyr_id = Cread["FYERS ID"]

        self.apps_id = Cread["APP ID"]
        self.apps_key = Cread["APP_KEY"]
        self.secret_keys = Cread["SECRET KEY"]
        self.totps = Cread["TOTP"]
        self.pin = Cread["PIN"]
        login(self.apps_id, self.secret_keys, self.fyr_id, self.totps, self.pin)

        today = str(dt.date.today())
        file1 = f"access_token{today}.txt"

        with open(f"utils/{file1}", "r") as file:
            self.access_token = file.read()

        fyers = fyersModel.FyersModel(client_id=f"M6YEDL33TV-100", token=self.access_token, log_path="utils/")
        if not self.ws_connect:
            self.connect_order_websocket()
        self.helper = FyersUtilities(fyers,self.fyers_web,self)

        self.helper.download_instruments()

        self.df = pd.read_csv(f"utils/Data_{today}.csv")

        index = ["NIFTY", "BANKNIFTY", "FINNIFTY","MIDCPNIFTY","BANKEX"]
        self.expiry = {}
        self.strike = {}
        for i in index:
            name = self.helper.index_expiry(self.df,i)
            atm = self.helper.index_atm(i)

            strike = self.helper.index_strike(self.df,i,atm)
            self.strike[i] = strike
            self.expiry[i] = name

        # print(self.strike)
        self.fut_stoke = self.helper.stock_symbol(self.df)
        self.fut_exp = self.helper.stock_expiry(self.df)


        self.create_frames()


        # self.expiry = self.exp

        # print(self.exp)


    def create_frames(self):
        main_frame1 = self.create_frame1()  # Frame 1 with the form layout
        main_frame2 = self.create_frame2()
        main_frame3 = self.create_frame3()
        main_frame4 = self.create_frame4()

        self.stack_layout.addWidget(main_frame1)
        self.stack_layout.addWidget(main_frame2)
        self.stack_layout.addWidget(main_frame3)
        self.stack_layout.addWidget(main_frame4)

        # Initially, only Frame 1 is visible
        self.stack_layout.setCurrentIndex(0)



    def create_frame1(self):
        # self.exp = ["None","hsadhfsks"]
        frame = QWidget()
        layout = QVBoxLayout()
        # frame_layout = QVBoxLayout()
        # frame.setLayout(QVBoxLayout())
        frame_title = QLabel('Trade Tool')
        frame_title.setStyleSheet('font-size: 20px; font-weight: bold; text-align: center; padding:0px 10px 10px 10px;')
        layout.addWidget(frame_title, alignment=Qt.AlignmentFlag.AlignCenter)



        # Add grid and bottom border to the main layout of frame2
        grid = QGridLayout()
        grid.setVerticalSpacing(12)  # Vertical padding
        grid.setHorizontalSpacing(10)  # Horizontal padding

        # Checkboxes
        self.index_cb = QCheckBox('Index')
        self.future_cb = QCheckBox('Future')


        self.lvl_price_cb = QCheckBox('Level Price')
        self.avg_price_cb = QCheckBox('Avg Price')
        # self.lite_mode_cb = QCheckBox('lite mode')
        self.avg_price_cb.clicked.connect(lambda: self.on_checkbox_clicked(self.avg_price_cb, self.lvl_price_cb))
        self.lvl_price_cb.clicked.connect(lambda: self.on_checkbox_clicked(self.lvl_price_cb, self.avg_price_cb))


        # ComboBox and LineEdits
        self.name_cb = QComboBox()
        self.strike_le = QComboBox()
        self.expiry_le = QComboBox()

        self.index_cb.stateChanged.connect(self.update_symbols)
        self.future_cb.stateChanged.connect(self.update_symbols)
        self.name_cb.currentIndexChanged.connect(self.update_expiry_dates)
        self.name_cb.currentIndexChanged.connect(self.update_strike_prices)

        self.name_cb.setEditable(True)
        self.strike_le.setEditable(True)
        self.update_symbols()

        # self.name_cb.addItems(self.expiry.keys())
        # self.name_cb.currentIndexChanged.connect(self.update_expiry_dates)

        # self.expiry_le.addItems(self.exp)

        # Action Checkboxes
        self.ce_cb = QCheckBox('CE')
        self.pe_cb = QCheckBox('PE')
        self.index_cb.clicked.connect(lambda: self.on_checkbox_clicked1(self.index_cb, self.future_cb,self.ce_cb, self.pe_cb, self.strike_le))
        self.future_cb.clicked.connect(lambda: self.on_checkbox2_clicked(self.future_cb, self.index_cb, self.ce_cb, self.pe_cb, self.strike_le))
        self.ce_cb.clicked.connect(lambda: self.on_checkbox_clicked(self.ce_cb, self.pe_cb))
        self.pe_cb.clicked.connect(lambda: self.on_checkbox_clicked(self.pe_cb, self.ce_cb))
        self.buy_cb = QCheckBox('Buy')
        self.sell_cb = QCheckBox('Sell')
        self.buy_cb.clicked.connect(lambda: self.on_checkbox_clicked(self.buy_cb, self.sell_cb))
        self.sell_cb.clicked.connect(lambda: self.on_checkbox_clicked(self.sell_cb, self.buy_cb))
        self.close_cb = QCheckBox('Close')

        # Interval and Above/Below
        self.interval_cb = QComboBox()
        self.interval_cb.setEnabled(False)
        self.interval_cb.setCurrentText("false")
        self.interval_cb.addItems(["1","3","5","15","30"])  # Example intervals
        self.close_cb.clicked.connect(lambda: self.on_checkbox2_clk_close(self.close_cb, self.interval_cb))
        self.above_cb = QCheckBox('Above')
        self.below_cb = QCheckBox('Below')
        self.above_cb.clicked.connect(lambda: self.on_checkbox_clicked(self.above_cb, self.below_cb))
        self.below_cb.clicked.connect(lambda: self.on_checkbox_clicked(self.below_cb, self.above_cb))

        # Order type Checkboxes
        self.strike_cb = QCheckBox('Strike')
        self.index_cb2 = QCheckBox('Index')
        self.strike_cb.clicked.connect(lambda: self.on_checkbox_clicked(self.strike_cb, self.index_cb2))
        self.index_cb2.clicked.connect(lambda: self.on_checkbox_clicked(self.index_cb2, self.strike_cb))

        self.abo_bolw_input_le = QLineEdit()
        self.abo_bolw_input_le.setPlaceholderText("......") # New input box
        self.Deviation = QLineEdit()
        self.Deviation.setPlaceholderText("Deviation")  # New input box
        self.limit_cb = QCheckBox('Limit')
        self.market_cb = QCheckBox('Market')
        self.limit_cb.clicked.connect(lambda: self.on_checkbox_clicked(self.limit_cb, self.market_cb))
        self.market_cb.clicked.connect(lambda: self.on_checkbox_clicked(self.market_cb, self.limit_cb))

        # Same strike Checkboxes
        # self.sl_lvl_cb = QCheckBox('Stop Loss Level')
        self.same_strike_cb = QCheckBox('Same Strike')
        self.ce_cb2 = QCheckBox('Ce')
        self.pe_cb2 = QCheckBox('Pe')
        self.ce_cb2.clicked.connect(lambda: self.on_checkbox_clicked(self.ce_cb2, self.pe_cb2))
        self.pe_cb2.clicked.connect(lambda: self.on_checkbox_clicked(self.pe_cb2, self.ce_cb2))



        self.strike_le2 = QComboBox()
        self.same_strike_cb.clicked.connect(lambda: self.on_checkbox2_clk_same_strike(self.same_strike_cb, self.ce_cb2, self.pe_cb2, self.strike_le2))

        # Stoploss and Target
        self.stoploss_cb = QCheckBox('Stoploss')
        self.index_cb3 = QCheckBox('Index')
        self.strike_cb2 = QCheckBox('Strike')
        self.index_cb3.clicked.connect(lambda: self.on_checkbox_clicked(self.index_cb3, self.strike_cb2))
        self.strike_cb2.clicked.connect(lambda: self.on_checkbox_clicked(self.strike_cb2, self.index_cb3))
        self.percent_cb = QCheckBox('%')
        self.point_cb = QCheckBox('Point')
        self.percent_cb.clicked.connect(lambda: self.on_checkbox_clicked(self.percent_cb, self.point_cb))
        self.point_cb.clicked.connect(lambda: self.on_checkbox_clicked(self.point_cb, self.percent_cb))
        self.limit_cb2 = QCheckBox('Limit')
        self.market_cb2 = QCheckBox('Market')
        self.limit_cb2.clicked.connect(lambda: self.on_checkbox_clicked(self.limit_cb2, self.market_cb2))
        self.market_cb2.clicked.connect(lambda: self.on_checkbox_clicked(self.market_cb2, self.limit_cb2))
        self.stoploss_le = QLineEdit()
        self.index_cb3.setEnabled(False)
        self.strike_cb2.setEnabled(False)
        self.percent_cb.setEnabled(False)
        self.point_cb.setEnabled(False)
        self.limit_cb2.setEnabled(False)
        self.market_cb2.setEnabled(False)
        self.stoploss_le.setEnabled(False)

        self.stoploss_cb.clicked.connect(lambda: self.on_checkbox2_clk_sl(self.stoploss_cb))

        self.target_cb = QCheckBox('Target')
        self.index_cb4 = QCheckBox('Index')
        self.strike_cb3 = QCheckBox('Strike')
        self.index_cb4.clicked.connect(lambda: self.on_checkbox_clicked(self.index_cb4, self.strike_cb3))
        self.strike_cb3.clicked.connect(lambda: self.on_checkbox_clicked(self.strike_cb3, self.index_cb4))
        self.percent_cb2 = QCheckBox('%')
        self.point_cb2 = QCheckBox('Point')
        self.percent_cb2.clicked.connect(lambda: self.on_checkbox_clicked(self.percent_cb2, self.point_cb2))
        self.point_cb2.clicked.connect(lambda: self.on_checkbox_clicked(self.point_cb2, self.percent_cb2))
        self.limit_cb3 = QCheckBox('Limit')
        self.market_cb3 = QCheckBox('Market')
        self.limit_cb3.clicked.connect(lambda: self.on_checkbox_clicked(self.limit_cb3, self.market_cb3))
        self.market_cb3.clicked.connect(lambda: self.on_checkbox_clicked(self.market_cb3, self.limit_cb3))
        self.target_le = QLineEdit()
        self.target_cb.clicked.connect(lambda: self.on_checkbox2_clk_tgt(self.target_cb))

        self.index_cb4.setEnabled(False)
        self.strike_cb3.setEnabled(False)
        self.percent_cb2.setEnabled(False)
        self.point_cb2.setEnabled(False)
        self.limit_cb3.setEnabled(False)
        self.market_cb3.setEnabled(False)
        self.target_le.setEnabled(False)


        self.lvl_price_cb.stateChanged.connect(self.stoploss_level)
        # self.target_cb.clicked.connect(lambda: self.on_checkbox2_clk_sl_tgt(self.target_cb,self.index_cb4, self.strike_cb3, self.percent_cb2, self.point_cb2,self.limit_cb3,self.market_cb3,self.target_le))

        # Quantity and Lot
        self.quantity_le = QCheckBox('Qty')
        self.lot_cb = QCheckBox('Lot')
        self.quantity_le.clicked.connect(lambda: self.on_checkbox_clicked(self.quantity_le, self.lot_cb))
        self.lot_cb.clicked.connect(lambda: self.on_checkbox_clicked(self.lot_cb, self.quantity_le))
        self.lot_le = QLineEdit()
        # self.quantity_le.clicked.connect(lambda: self.on_checkbox_clicked(self.quantity_le, self.lot_cb))
        # self.lot_cb.clicked.connect(lambda: self.on_checkbox_clicked(self.lot_cb, self.quantity_le))
        # # self.lot_cb.addItems(["lot1", "lot2", "lot3"])
          # Example lots

        # Set fixed width for LineEdits
        self.name_cb.setFixedWidth(120)
        # self.strike_le.setFixedWidth(60)
        # self.expiry_le.setFixedWidth(60)
        # self.additional_input_le.setFixedWidth(60)
        # self.additional_input_le2.setFixedWidth(60)
        # self.strike_le2.setFixedWidth(60)
        # self.stoploss_le.setFixedWidth(60)
        # self.target_le.setFixedWidth(60)
        # self.quantity_le.setFixedWidth(60)
        # self.lot_cb.setFixedWidth(60)

        # Order Place Button
        self.order_place_btn = QPushButton('ORDER PLACE')
        self.order_place_btn.setFixedWidth(300)
        self.order_place_btn.clicked.connect(self.place_order)

        # Add widgets to grid
        grid.addWidget(self.index_cb, 0, 0)
        grid.addWidget(self.future_cb, 0, 1)
        grid.addWidget(self.lvl_price_cb, 0, 4)
        grid.addWidget(self.avg_price_cb, 0, 5)
        # grid.addWidget(self.lite_mode_cb, 0, 4)
        grid.addWidget(QLabel('Name'), 1, 0)
        grid.addWidget(self.name_cb, 1, 1)  # Span two columns
        grid.addWidget(QLabel('Strike'), 1, 2)
        grid.addWidget(self.strike_le, 1, 3)

        grid.addWidget(self.ce_cb, 2, 0)
        grid.addWidget(self.pe_cb, 2, 1)
        grid.addWidget(QLabel('Expiry'), 2, 2)
        grid.addWidget(self.expiry_le, 2, 3)  # Span two columns
        grid.addWidget(self.above_cb, 2, 4)
        grid.addWidget(self.below_cb, 2, 5)

        grid.addWidget(self.buy_cb, 3, 0)
        grid.addWidget(self.sell_cb, 3, 1)
        grid.addWidget(self.close_cb, 3, 2)
        grid.addWidget(QLabel('Interval'), 3, 3)
        grid.addWidget(self.interval_cb, 3, 4)
        grid.addWidget(self.Deviation, 3, 5)  # New input box

        grid.addWidget(self.strike_cb, 4, 0)
        grid.addWidget(self.index_cb2, 4, 1)
        grid.addWidget(self.abo_bolw_input_le, 4, 2)  # New input box
        grid.addWidget(self.limit_cb, 4, 3)
        grid.addWidget(self.market_cb, 4, 4)

        # grid.addWidget(self.sl_lvl_cb, 5,0)
        grid.addWidget(self.same_strike_cb, 5, 0)
        grid.addWidget(self.ce_cb2, 5, 1)
        grid.addWidget(self.pe_cb2, 5, 2)
        grid.addWidget(QLabel('Strike'), 5, 3)
        grid.addWidget(self.strike_le2, 5, 4)

        grid.addWidget(self.stoploss_cb, 6, 0)
        grid.addWidget(self.index_cb3, 6, 1)
        grid.addWidget(self.strike_cb2, 6, 2)
        grid.addWidget(self.percent_cb, 6, 3)
        grid.addWidget(self.point_cb, 6, 4)
        grid.addWidget(self.stoploss_le, 6, 5)

        grid.addWidget(self.limit_cb2, 7, 0)
        grid.addWidget(self.market_cb2, 7, 1)

        grid.addWidget(self.target_cb, 8, 0)
        grid.addWidget(self.index_cb4, 8, 1)
        grid.addWidget(self.strike_cb3, 8, 2)
        grid.addWidget(self.percent_cb2, 8, 3)
        grid.addWidget(self.point_cb2, 8, 4)
        grid.addWidget(self.target_le, 8, 5)

        grid.addWidget(self.limit_cb3, 9, 0)
        grid.addWidget(self.market_cb3, 9, 1)

        grid.addWidget(QLabel('Quantity'), 10, 0)
        grid.addWidget(self.quantity_le, 10, 1)
        # grid.addWidget(QLabel('Lot'), 10, 2)
        grid.addWidget(self.lot_cb, 10, 2)
        grid.addWidget(self.lot_le, 10, 3)

        # Add grid to layout
        layout.addLayout(grid)

        # Add spacer and button to layout
        layout.addSpacerItem(QSpacerItem(20, 40, QSizePolicy.Policy.Minimum, QSizePolicy.Policy.Expanding))
        layout.addWidget(self.order_place_btn, alignment=Qt.AlignmentFlag.AlignCenter)

        # Bottom border frame
        frame.setLayout(layout)
        # self.setCentralWidget(frame)
        return frame


    def stoploss_level(self):
        if self.lvl_price_cb.isChecked() or self.avg_price_cb.isChecked():
            self.same_strike_cb.setEnabled(False)
            self.ce_cb2.setEnabled(False)
            self.pe_cb2.setEnabled(False)
            self.index_cb3.setEnabled(False)
            self.index_cb4.setEnabled(False)
            self.strike_cb2.setEnabled(False)
            self.strike_cb3.setEnabled(False)
            self.same_strike_cb.setChecked(False)
            self.ce_cb2.setChecked(False)
            self.pe_cb2.setChecked(False)
            self.index_cb3.setChecked(False)
            self.index_cb4.setChecked(False)
            self.strike_cb2.setChecked(False)
            self.strike_cb3.setChecked(False)

        # if self.stoploss_cb.isChecked():
        #     self.lvl_price_cb.setEnabled(False)

        else:
            self.ce_cb2.setEnabled(True)
            self.pe_cb2.setEnabled(True)
            self.same_strike_cb.setEnabled(True)
            # self.index_cb3.setEnabled(True)
            # self.index_cb4.setEnabled(True)
            # self.strike_cb2.setEnabled(True)
            # self.strike_cb3.setEnabled(True)
            self.same_strike_cb.setChecked(False)
            self.ce_cb2.setChecked(False)
            self.pe_cb2.setChecked(False)
            self.index_cb3.setChecked(False)
            self.index_cb4.setChecked(False)
            self.strike_cb2.setChecked(False)
            self.strike_cb3.setChecked(False)
            # self.lvl_price_cb.setEnabled(True)

    def update_expiry_dates(self, index=0):
        symbol = self.name_cb.currentText()
        self.expiry_le.clear()
        if self.future_cb.isChecked():
            self.expiry_le.addItems(self.fut_exp)
        elif self.index_cb.isChecked() and symbol in self.expiry:
            self.expiry_le.addItems(self.expiry[symbol])

    def update_strike_prices(self, index=0):
        symbol = self.name_cb.currentText()
        self.strike_le.clear()
        self.strike_le2.clear()
        if symbol in self.strike:
            self.strike_le.addItems([str(price) for price in self.strike[symbol]])
            self.strike_le2.addItems([str(price) for price in self.strike[symbol]])

        # Set completer for strike prices
        completer = QCompleter([str(price) for price in self.strike.get(symbol, [])])
        completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.strike_le.setCompleter(completer)
        # self.strike_le2.setCompleter(completer)

    def update_symbols(self):
        completer = QCompleter()
        completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)

        if self.future_cb.isChecked():
            self.name_cb.clear()
            self.name_cb.addItems(self.fut_stoke)
            completer.setModel(self.name_cb.model())
            self.name_cb.setCompleter(completer)
            self.update_expiry_dates()
            self.update_strike_prices()

        elif self.index_cb.isChecked():
            self.name_cb.clear()
            self.name_cb.addItems(self.expiry.keys())
            completer.setModel(self.name_cb.model())
            self.name_cb.setCompleter(completer)
            self.update_expiry_dates()
            self.update_strike_prices()

    # def update_expiry_dates(self, index):
    #     symbol = self.name_cb.currentText()
    #     self.expiry_le.clear()
    #     self.expiry_le.addItems(self.expiry[symbol])

    def on_checkbox2_clicked(self, clicked_checkbox, other_checkbox1, other_checkbox2, other_checkbox3, line_edit):
        if clicked_checkbox == clicked_checkbox and clicked_checkbox.isChecked():
            other_checkbox1.setChecked(False)
            other_checkbox2.setChecked(False)
            other_checkbox3.setChecked(False)
            # other_checkbox1.setEnabled(False)
            other_checkbox2.setEnabled(False)
            other_checkbox3.setEnabled(False)
            line_edit.setEnabled(False)
            self.strike_cb.setEnabled(False)
            self.index_cb2.setEnabled(False)
            self.same_strike_cb.setEnabled(False)
            self.ce_cb2.setEnabled(False)
            self.pe_cb2.setEnabled(False)
            self.strike_le2.setEnabled(False)
            self.index_cb3.setEnabled(False)
            self.strike_cb2.setEnabled(False)
            self.index_cb4.setEnabled(False)
            self.strike_cb3.setEnabled(False)
        else:
            other_checkbox1.setChecked(True)
            other_checkbox2.setEnabled(False)
            other_checkbox3.setEnabled(False)
            line_edit.setEnabled(False)
            self.strike_cb.setEnabled(True)
            self.index_cb2.setEnabled(True)
            self.same_strike_cb.setEnabled(True)
            self.ce_cb2.setEnabled(True)
            self.pe_cb2.setEnabled(True)
            self.strike_le2.setEnabled(True)
            # self.index_cb3.setEnabled(True)
            # self.strike_cb2.setEnabled(True)
            # self.index_cb4.setEnabled(True)
            # self.strike_cb3.setEnabled(True)
        #     other_checkbox2.setEnabled(True)
        #     other_checkbox3.setEnabled(True)
        #     line_edit.setEnabled(True)

    def on_checkbox2_clk_same_strike(self, clicked_checkbox, other_checkbox1, other_checkbox2, line_edit):
        if clicked_checkbox == self.same_strike_cb and clicked_checkbox.isChecked():
            other_checkbox1.setChecked(False)
            other_checkbox2.setChecked(False)
            other_checkbox1.setEnabled(False)
            other_checkbox2.setEnabled(False)
            self.index_cb3.setEnabled(False)
            self.index_cb4.setEnabled(False)
            # self.strike_cb2.setEnabled(False)
            # self.strike_cb3.setEnabled(False)
            other_checkbox2.setEnabled(False)
            line_edit.setEnabled(False)
        else:
            other_checkbox1.setEnabled(True)
            other_checkbox2.setEnabled(True)
            line_edit.setEnabled(True)

    def on_checkbox2_clk_close(self, clicked_checkbox,line_edit):
        if clicked_checkbox == clicked_checkbox and clicked_checkbox.isChecked():
            line_edit.setEnabled(True)
        else:
            line_edit.setEnabled(False)
            line_edit.setCurrentText("false")

    def on_checkbox2_clk_sl(self, clicked_checkbox):
        if self.stoploss_cb == clicked_checkbox and self.stoploss_cb.isChecked() and not (self.lvl_price_cb.isChecked() or self.avg_price_cb.isChecked()):
            self.index_cb3.setEnabled(True)
            self.strike_cb2.setEnabled(True)
            self.percent_cb.setEnabled(True)
            self.point_cb.setEnabled(True)
            self.limit_cb2.setEnabled(True)
            self.market_cb2.setEnabled(True)
            self.stoploss_le.setEnabled(True)
            self.index_cb3.setChecked(False)
            self.strike_cb2.setChecked(False)
            self.percent_cb.setChecked(False)
            self.point_cb.setChecked(False)
            self.limit_cb2.setChecked(False)
            self.market_cb2.setChecked(False)

        elif self.stoploss_cb.isChecked() and (self.lvl_price_cb.isChecked() or self.avg_price_cb.isChecked()):
            self.percent_cb.setEnabled(True)
            self.point_cb.setEnabled(True)
            self.limit_cb2.setEnabled(True)
            self.market_cb2.setEnabled(True)
            self.stoploss_le.setEnabled(True)
            self.percent_cb.setChecked(False)
            self.point_cb.setChecked(False)
            self.limit_cb2.setChecked(False)
            self.market_cb2.setChecked(False)
        else:
            self.index_cb3.setChecked(False)
            self.strike_cb2.setChecked(False)
            self.percent_cb.setChecked(False)
            self.point_cb.setChecked(False)
            self.limit_cb2.setChecked(False)
            self.market_cb2.setChecked(False)
            self.stoploss_le.setEnabled(False)
            self.index_cb3.setEnabled(False)
            self.strike_cb2.setEnabled(False)
            self.percent_cb.setEnabled(False)
            self.point_cb.setEnabled(False)
            self.limit_cb2.setEnabled(False)
            self.market_cb2.setEnabled(False)

    def on_checkbox2_clk_tgt(self, clicked_checkbox):
        if self.target_cb == clicked_checkbox and self.target_cb.isChecked() and not (self.lvl_price_cb.isChecked() or self.avg_price_cb.isChecked()):
            self.index_cb4.setEnabled(True)
            self.strike_cb3.setEnabled(True)
            self.percent_cb2.setEnabled(True)
            self.point_cb2.setEnabled(True)
            self.limit_cb3.setEnabled(True)
            self.market_cb3.setEnabled(True)
            self.target_le.setEnabled(True)
            self.index_cb4.setChecked(False)
            self.strike_cb3.setChecked(False)
            self.percent_cb2.setChecked(False)
            self.point_cb2.setChecked(False)
            self.limit_cb3.setChecked(False)
            self.market_cb3.setChecked(False)

        elif self.target_cb.isChecked() and (self.lvl_price_cb.isChecked() or self.avg_price_cb.isChecked()) :
            self.percent_cb2.setEnabled(True)
            self.point_cb2.setEnabled(True)
            self.limit_cb3.setEnabled(True)
            self.market_cb3.setEnabled(True)
            self.target_le.setEnabled(True)
            self.percent_cb2.setChecked(False)
            self.point_cb2.setChecked(False)
            self.limit_cb3.setChecked(False)
            self.market_cb3.setChecked(False)
        else:
            self.index_cb4.setChecked(False)
            self.strike_cb3.setChecked(False)
            self.percent_cb2.setChecked(False)
            self.point_cb2.setChecked(False)
            self.limit_cb3.setChecked(False)
            self.market_cb3.setChecked(False)
            self.target_le.setEnabled(False)
            self.index_cb4.setEnabled(False)
            self.strike_cb3.setEnabled(False)
            self.percent_cb2.setEnabled(False)
            self.point_cb2.setEnabled(False)
            self.limit_cb3.setEnabled(False)
            self.market_cb3.setEnabled(False)




    def on_checkbox_clicked1(self,frame1,frame2,other_checkbox2, other_checkbox3, line_edit):
        if frame1.isChecked():
            frame2.setChecked(False)
            other_checkbox2.setEnabled(True)
            other_checkbox3.setEnabled(True)
            line_edit.setEnabled(True)
            self.strike_cb.setEnabled(True)
            self.index_cb2.setEnabled(True)
            self.same_strike_cb.setEnabled(True)
            self.ce_cb2.setEnabled(True)
            self.pe_cb2.setEnabled(True)
            self.strike_le2.setEnabled(True)
        else:
            frame2.setChecked(True)
            other_checkbox2.setEnabled(False)
            other_checkbox3.setEnabled(False)
            line_edit.setEnabled(False)


    def on_checkbox_clicked(self,frame1,frame2):
        if frame1.isChecked():
            frame2.setChecked(False)


    def create_frame2(self):
        frame2 = QWidget()

        # Create the layout for Frame2
        frame2_layout = QGridLayout()
        frame2_layout.setHorizontalSpacing(10)

        # Checkboxes for trade options
        self.index_checkbox = QCheckBox('Index')
        self.future_checkbox = QCheckBox('Future')
        # self.index_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.index_checkbox, self.future_checkbox))
        # self.future_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.future_checkbox, self.index_checkbox))
        self.avg_price_checkbox = QCheckBox('Average Price')
        self.first_lot_checkbox = QCheckBox('First Lot')
        self.avg_price_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.avg_price_checkbox, self.first_lot_checkbox))
        self.first_lot_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.first_lot_checkbox, self.avg_price_checkbox))
        # self.lite_mode_checkbox = QCheckBox('Lite Mode')


        # Name ComboBox
        self.name_label = QLabel('Name')
        self.name_combo_box = QComboBox()
        self.name_combo_box.setFixedWidth(120)


        # Strike LineEdit
        self.strike_label = QLabel('Strike')
        self.strike_line_edit = QComboBox()


        # Option type Checkboxes (CE / PE)
        self.ce_checkbox = QCheckBox('CE')
        self.pe_checkbox = QCheckBox('PE')
        self.ce_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.ce_checkbox, self.pe_checkbox))
        self.pe_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.pe_checkbox, self.ce_checkbox))
        self.index_checkbox.clicked.connect(lambda: self.on_checkbox_clicked1(self.index_checkbox, self.future_checkbox,self.ce_checkbox, self.pe_checkbox, self.strike_line_edit))
        self.future_checkbox.clicked.connect(lambda: self.on_checkbox2_clicked(self.future_checkbox, self.index_checkbox, self.ce_checkbox, self.pe_checkbox, self.strike_line_edit))
        self.expiry_label = QLabel('Expiry')
        self.expiry_line_edit = QComboBox()


        self.index_checkbox.stateChanged.connect(self.update_symbols2)
        self.future_checkbox.stateChanged.connect(self.update_symbols2)
        self.name_combo_box.currentIndexChanged.connect(self.update_expiry_dates2)
        self.name_combo_box.currentIndexChanged.connect(self.update_strike_prices2)

        self.name_combo_box.setEditable(True)
        self.strike_line_edit.setEditable(True)
        self.update_symbols2()




        # Buy/Sell checkboxes and Price Range (Above/Below)
        self.buy_checkbox = QCheckBox('Buy')
        self.sell_checkbox = QCheckBox('Sell')
        self.buy_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.buy_checkbox, self.sell_checkbox))
        self.sell_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.sell_checkbox, self.buy_checkbox))
        self.above_checkbox = QCheckBox('Above')
        self.below_checkbox = QCheckBox('Below')
        self.above_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.above_checkbox, self.below_checkbox))
        self.below_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.below_checkbox, self.above_checkbox))


        # Strike/Index Section
        self.strike_checkbox = QCheckBox('Strike')
        self.index_checkbox_2 = QCheckBox('Index')
        self.strike_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.strike_checkbox, self.index_checkbox_2))
        self.index_checkbox_2.clicked.connect(lambda: self.on_checkbox_clicked(self.index_checkbox_2, self.strike_checkbox))
        self.index_line_edit = QLineEdit()


        # Stoploss options
        self.stoploss_checkbox = QCheckBox('Stoploss')
        self.stoploss_percent_checkbox = QCheckBox('%')
        self.stoploss_points_checkbox = QCheckBox('Points')
        self.stoploss_percent_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.stoploss_percent_checkbox, self.stoploss_points_checkbox))
        self.stoploss_points_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.stoploss_points_checkbox, self.stoploss_percent_checkbox))
        self.stoploss_line_edit = QLineEdit()


        # Target options
        self.target_checkbox = QCheckBox('Target')
        self.target_percent_checkbox = QCheckBox('%')
        self.target_points_checkbox = QCheckBox('Points')
        self.target_percent_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.target_percent_checkbox, self.target_points_checkbox))
        self.target_points_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.target_points_checkbox, self.target_percent_checkbox))
        self.target_line_edit = QLineEdit()


        # Quantity and Lot ComboBox
        self.quantity_label = QLabel('Quantity')
        # self.quantity_line_edit = QLineEdit()
        # self.lot_label = QLabel('Lot')
        # self.lot_combo_box = QComboBox()

        # self.avg_price_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.avg_price_checkbox, self.first_lot_checkbox))
        # self.first_lot_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.first_lot_checkbox, self.avg_price_checkbox))

        self.quantity_checkbox = QCheckBox('Qty')
        self.lot_checkbox = QCheckBox('Lot')
        self.quantity_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.quantity_checkbox, self.lot_checkbox))
        self.lot_checkbox.clicked.connect(lambda: self.on_checkbox_clicked(self.lot_checkbox, self.quantity_checkbox))
        self.lot_line_edit = QLineEdit()

        # Order Button
        self.order_button = QPushButton('Order Place')
        self.order_button.clicked.connect(self.place_order_litemode)

        frame2_layout.addWidget(self.index_checkbox, 0, 0)
        frame2_layout.addWidget(self.future_checkbox, 0, 1)
        frame2_layout.addWidget(self.avg_price_checkbox, 0, 2)
        frame2_layout.addWidget(self.first_lot_checkbox, 0, 3)
        # frame2_layout.addWidget(self.lite_mode_checkbox, 0, 4)

        frame2_layout.addWidget(self.name_label, 1, 0)
        frame2_layout.addWidget(self.name_combo_box, 1, 1)
        frame2_layout.addWidget(self.strike_label, 1, 2)
        frame2_layout.addWidget(self.strike_line_edit, 1, 3)

        frame2_layout.addWidget(self.ce_checkbox, 2, 0)
        frame2_layout.addWidget(self.pe_checkbox, 2, 1)
        frame2_layout.addWidget(self.expiry_label, 2, 2)
        frame2_layout.addWidget(self.expiry_line_edit, 2, 3)

        frame2_layout.addWidget(self.buy_checkbox, 3, 0)
        frame2_layout.addWidget(self.sell_checkbox, 3, 1)
        frame2_layout.addWidget(self.above_checkbox, 3, 2)
        frame2_layout.addWidget(self.below_checkbox, 3, 3)

        frame2_layout.addWidget(self.strike_checkbox, 4, 0)
        frame2_layout.addWidget(self.index_checkbox_2, 4, 1)
        frame2_layout.addWidget(self.index_line_edit, 4, 2)

        frame2_layout.addWidget(self.stoploss_checkbox, 5, 0)
        frame2_layout.addWidget(self.stoploss_percent_checkbox, 5, 1)
        frame2_layout.addWidget(self.stoploss_points_checkbox, 5, 2)
        frame2_layout.addWidget(self.stoploss_line_edit, 5, 3)

        frame2_layout.addWidget(self.target_checkbox, 6, 0)
        frame2_layout.addWidget(self.target_percent_checkbox, 6, 1)
        frame2_layout.addWidget(self.target_points_checkbox, 6, 2)
        frame2_layout.addWidget(self.target_line_edit, 6, 3)

        frame2_layout.addWidget(self.quantity_label, 7, 0)
        frame2_layout.addWidget(self.quantity_checkbox, 7, 1)
        frame2_layout.addWidget(self.lot_checkbox, 7, 2)
        frame2_layout.addWidget(self.lot_line_edit, 7, 3)

        frame2_layout.addWidget(self.order_button, 8, 0, 1, 5)


        # Set layout for Frame2 and return it
        frame2.setLayout(frame2_layout)

        return frame2


    def update_expiry_dates2(self, index=0):
        symbol = self.name_combo_box.currentText()
        self.expiry_line_edit.clear()
        if self.future_checkbox.isChecked():
            self.expiry_line_edit.addItems(self.fut_exp)
        elif self.index_checkbox.isChecked() and symbol in self.expiry:
            self.expiry_line_edit.addItems(self.expiry[symbol])

    def update_strike_prices2(self, index=0):
        symbol = self.name_combo_box.currentText()
        self.strike_line_edit.clear()
        if symbol in self.strike:
            self.strike_line_edit.addItems([str(price) for price in self.strike[symbol]])

        # Set completer for strike prices
        completer = QCompleter([str(price) for price in self.strike.get(symbol, [])])
        completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        self.strike_line_edit.setCompleter(completer)

    def update_symbols2(self):
        completer = QCompleter()
        completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)

        if self.future_checkbox.isChecked():
            self.name_combo_box.clear()
            self.name_combo_box.addItems(self.fut_stoke)
            completer.setModel(self.name_cb.model())
            self.name_combo_box.setCompleter(completer)
            self.update_expiry_dates2()
            self.update_strike_prices2()
        elif self.index_checkbox.isChecked():
            self.name_combo_box.clear()
            self.name_combo_box.addItems(self.expiry.keys())
            completer.setModel(self.name_combo_box.model())
            self.name_combo_box.setCompleter(completer)
            self.update_expiry_dates2()
            self.update_strike_prices2()


    def create_frame3(self):
        frame1 = QWidget(self)
        # Add labels for headings
        position_label = QLabel('POSITION', frame1)
        position_label.move(30, 20)  # Absolute positioning
        position_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        quantity_label = QLabel('QUANTITY', frame1)
        quantity_label.move(220, 20)  # Absolute positioning
        quantity_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        # Add first position, quantity, and checkbox
        position_label1 = QLabel('BANKNIFTY24943AYE52300CE', frame1)
        position_label1.move(30, 60)  # Absolute positioning
        quantity_label1 = QLabel('30', frame1)
        quantity_label1.move(220, 60)  # Absolute positioning
        checkbox1 = QCheckBox('', frame1)
        checkbox1.move(340, 60)  # Absolute positioning
        # Add second position, quantity, and checkbox
        position_label2 = QLabel('BANKNIFTY24943AYE51000CE', frame1)
        position_label2.move(30, 100)  # Absolute positioning
        quantity_label2 = QLabel('50', frame1)
        quantity_label2.move(220, 100)  # Absolute positioning
        checkbox2 = QCheckBox('', frame1)
        checkbox2.move(340, 100)  # Absolute positioning
        # Add third position, quantity, and checkbox
        position_label3 = QLabel('NIFTY24943AYE25000PE', frame1)
        position_label3.move(30, 140)  # Absolute positioning
        quantity_label3 = QLabel('70', frame1)
        quantity_label3.move(220, 140)  # Absolute positioning
        checkbox3 = QCheckBox('', frame1)
        checkbox3.move(340, 140)  # Absolute positioning
        # Add buttons
        self.edit_all_button = QPushButton('EDIT ALL', frame1)
        self.edit_all_button.move(30, 200)  # Absolute positioning
        self.grab_button = QPushButton('GRAB', frame1)
        self.grab_button.move(129, 200)  # Absolute positioning
        self.edit_button = QPushButton('EDIT', frame1)
        self.edit_button.move(220, 200)  # Absolute positioning
        self.exit_button = QPushButton('EXIT', frame1)
        self.exit_button.move(295, 200)  # Absolute positioning
        self.edit_all_button.clicked.connect(lambda: self.show_confirmation('EDIT ALL'))
        self.grab_button.clicked.connect(lambda: self.show_confirmation('GRAB'))
        self.edit_button.clicked.connect(lambda: self.show_confirmation('EDIT'))
        self.exit_button.clicked.connect(lambda: self.show_confirmation('EXIT'))
        # Add square of button
        self.square_button = QPushButton('SQUARE OF ALL', frame1)
        self.square_button.move(30, 250)  # Absolute positioning
        self.square_button.clicked.connect(lambda: self.show_confirmation('SQUARE OF ALL'))
        self.square_button.setStyleSheet("QPushButton { padding: 5px 125px;}")
        self.apply_stylesheet()
        return frame1

    def show_confirmation(self, action):
        reply = QMessageBox.question(self, 'Confirmation', f'Are you sure you want to {action}?',
                                     QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                     QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            print(f'Confirmed {action}')
        else:
            print(f'Cancelled {action}')

    def apply_stylesheet(self):
        style_sheet = """
        QLabel {
            font-size: 12px;
        }
        QPushButton {
            font-size: 12px;
            padding: 5px 20px;
        }
        """
        self.setStyleSheet(style_sheet)

    def create_frame4(self):
        frame = QWidget()
        login_frame_layout = QVBoxLayout()
        login_title = QLabel('Login')
        login_title.setStyleSheet('font-size: 20px; font-weight: bold; text-align: center;')
        login_frame_layout.addWidget(login_title, alignment=Qt.AlignmentFlag.AlignCenter)

        login_form_layout = QFormLayout()

        self.fyers_id_input = QLineEdit()
        login_form_layout.addRow('FYERS ID:', self.fyers_id_input)

        self.app_id_input = QLineEdit()
        login_form_layout.addRow('APP ID:', self.app_id_input)

        self.secret_key_input = QLineEdit()
        login_form_layout.addRow('SECRET KEY:', self.secret_key_input)

        self.totp_input = QLineEdit()
        login_form_layout.addRow('TOTP:', self.totp_input)


        self.pin_input = QLineEdit()
        self.pin_input.setEchoMode(QLineEdit.EchoMode.Password)

        self.show_password_button = QToolButton(self.pin_input)
        self.show_password_button.setIcon(QIcon("assets/hide.png"))  # Path to eye icon
        self.show_password_button.setCheckable(True)
        self.show_password_button.setCursor(Qt.CursorShape.PointingHandCursor)

        self.show_password_button.setStyleSheet("""
            QToolButton {
                border: none;
                background: transparent;
            }
        """)

        self.show_password_button.clicked.connect(self.toggle_password_visibility)

        # Add button inside QLineEdit
        self.pin_input.setLayout(QVBoxLayout())
        self.pin_input.layout().setContentsMargins(0, 0, 5, 0)
        self.pin_input.layout().addWidget(self.show_password_button, alignment=Qt.AlignmentFlag.AlignRight)

        login_form_layout.addRow('PIN:', self.pin_input)

        login_frame_layout.addLayout(login_form_layout)

        login_button = QPushButton('Save')
        login_button.clicked.connect(self.save_input_values)
        login_frame_layout.addWidget(login_button, alignment=Qt.AlignmentFlag.AlignCenter)
        frame.setLayout(login_frame_layout)
        return frame


    def toggle_password_visibility(self):
        if self.show_password_button.isChecked():
            self.pin_input.setEchoMode(QLineEdit.EchoMode.Normal)
            self.show_password_button.setIcon(QIcon("assets/eye.png"))  # Path to eye-off icon
        else:
            self.pin_input.setEchoMode(QLineEdit.EchoMode.Password)
            self.show_password_button.setIcon(QIcon("assets/hide.png"))


    def display_frame(self, index):
        self.stack_layout.setCurrentIndex(index)

    def save_input_values(self):
        if not all([self.fyers_id_input.text(), self.app_id_input.text(), self.secret_key_input.text(), self.totp_input.text(), self.pin_input.text()]):
            QMessageBox.critical(self, "Input Error", "Please ensure all inputs are filled correctly.")
            return
        confirm = QMessageBox.question(self, "Confirm Details", "Please confirm that all details are correct. Do you want to proceed?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if confirm != QMessageBox.StandardButton.Yes:
            return
        self.input_data = {
            "FYERS_ID": str(self.fyers_id_input.text()),
            "APP_ID": str(self.app_id_input.text()),
            "SECRET_KEY": str(self.secret_key_input.text()),
            "TOTP": str(self.totp_input.text()),
            "PIN": str(self.pin_input.text())
        }
        with open("json/secret.json", "w") as file:
            json.dump(self.input_data, file)






# MAIN LOGIC @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@




    def onmessage(self,message):
        # print("Response:", message)
        try:
            if "ltp" in message:
                self.ltp_data[message["symbol"]] = message["ltp"]
            # print(f"Ltp Data {self.ltp_data}")
        except Exception as e:
            print(f"Fetching Ltp {e}")

    def onopen(self):
        '''

            symbol

        # elif self.index_cb2.isChecked():
        #     symbol = self.helper.ind_ltp_data_symbol(self.strike_cb,self.strike_le,self.ce_cb,self.pe_cb,self.df,self.name_cb,self.index_cb2,self.future_cb)
        #     self.status["symbol"] = symbol[0]
        #     self.status["ltp_symbol"] = symbol[1]
            # self.status["sl_index"] = symbol[1]


        '''
        # print(symbol)
        data_type = "SymbolUpdate"
        self.fyers_web.subscribe(symbols=['NSE:NIFTY50-INDEX','NSE:NIFTYBANK-INDEX','NSE:FINNIFTY-INDEX','NSE:MIDCPNIFTY-INDEX','BSE:BANKEX-INDEX','BSE:SENSEX-INDEX'], data_type=data_type)
        self.fyers_web.keep_running()

    def set_symbol(self):
        if self.index_cb.isChecked():
            self.ce = self.ce_cb
            self.pe = self.pe_cb
            self.strk = self.strike_le

            self.symbol = self.helper.ind_ltp_data_symbol(self.strk,self.ce,self.pe,self.df,self.name_cb,self.index_cb,self.future_cb)

            if self.name_cb.currentText() == "BANKNIFTY":
                self.ind_symbol = [f"NSE:NIFTYBANK-INDEX"]
            elif self.name_cb.currentText() == "NIFTY":
                self.ind_symbol = [f"NSE:NIFTY50-INDEX"]
            elif self.name_cb.currentText() == "FINNIFTY":
                self.ind_symbol = [f"NSE:FINNIFTY-INDEX"]
            elif self.name_cb.currentText() == "MIDCPNIFTY":
                self.ind_symbol = [f"NSE:MIDCPNIFTY-INDEX"]
            elif self.name_cb.currentText() == "BANKEX":
                self.ind_symbol = [f"BSE:BANKEX-INDEX"]
            elif self.name_cb.currentText() == "SENSEX":
                self.ind_symbol = [f"BSE:SENSEX-INDEX"]

            self.status["symbol"] = self.symbol[0]
            self.status["ltp_symbol"] = self.ind_symbol[0]

        elif self.future_cb.isChecked():
            self.symbol = self.helper.ind_ltp_data_symbol(self.strike_cb,self.strike_le,self.ce_cb,self.pe_cb,self.df,self.name_cb,self.index_cb2,self.future_cb)
            self.status["symbol"] = self.symbol


        # Websocket Connect
    def on_order(self,message):
        try:
            # order_details = parse_master_order(message)
            order = message.get('orders', {})
            self.order_data.update({order.get("symbol"):{
                    "order_id": order.get("id"),
                    "symbol": order.get("symbol"),
                    "segment": order.get("segment"),
                    "quantity": int(order.get("qty")),
                    "price": order.get("price",0),
                    "side": "BUY" if order.get("side") == 1 else "SELL",
                    "type": order.get("type"),
                    "limitPrice": order.get("limitPrice",0),
                    "stopPrice": order.get("stopPrice",0),
                    "status": order.get("status"),
                    "productType":order.get("productType"),
                    "message": order.get("message"),
                    "timestamp": order.get("orderDateTime")}})
            # print(f"Order Data {self.order_data}")

        except Exception as e:
            print(f"Error parsing master order data: {e}")
            return None

    def on_open(self):
        try:
            # Specify the data type for subscription
            data_type = "OnOrders"  # Subscribing only to order-related events
            self.fyers_od.subscribe(data_type=data_type)

            # Keep the socket running to receive real-time data
            self.fyers_od.keep_running()

        except Exception as e:
            print(f"Error in on_open callback: {e}")

    def connect_order_websocket(self):
        self.ws_connect = True
        try:
            self.fyers_web = data_ws.FyersDataSocket(
                access_token=f"{self.apps_key}:{self.access_token}",
                log_path="utils/",
                litemode=True,
                write_to_file=False,
                reconnect=True,
                on_connect=self.onopen,
                on_message=self.onmessage,
            )
            self.fyers_web.connect()
            # Initialize Fyers Order WebSocket
            self.fyers_od = order_ws.FyersOrderSocket(
                access_token=f"{self.apps_key}:{self.access_token}",  # Your Fyers API access token.
                write_to_file=False,        # Do not write logs to a file.
                log_path="utils/",          # Log path for logs (change as needed).
                on_connect=self.on_open,         # Callback for WebSocket connection success.1
                on_orders=self.on_order)
            # Connect to the WebSocket
            self.fyers_od.connect()
            print("status", "success", "message", "Order WebSocket connected successfully!")
        except Exception as e:
            print(f"Order WebSocket connection failed: {e}")



    def break_out_thread(self):
        threading.Thread(target=self.helper.break_out_entry, args=(self.name_cb,self.quantity_le,self.lot_le,self.df,self,self.status,self.ltp_data,self.percent_cb,self.point_cb,self.percent_cb2,self.point_cb2,self.target_le,self.stoploss_le,self.index_cb3,self.strike_cb2,self.index_cb4,self.strike_cb3,self.abo_bolw_input_le,self.index_cb2,self.strike_cb,self.above_cb,self.below_cb,self.index_cb,self.buy_cb,self.sell_cb,self.close_cb,self.Deviation,self.limit_cb,self.stoploss_cb,self.target_cb,self.lot_cb,self.market_cb,self.lvl_price_cb,self.avg_price_cb,self.order_data,self.strike_le2,self.same_strike_cb,self.ce_cb2,self.pe_cb2,self.ce_cb,self.pe_cb)).start()


    def place_order(self):
        if self.index_cb.isChecked():
            self.set_symbol()
            self.helper.subscribe_symbol(self.symbol)

            if self.close_cb.isChecked():
                if self.strike_cb.isChecked():
                    symbol_list = [self.status["symbol"]]
                    self.helper.get_data_downloader(symbol_list,self.interval_cb)
                elif self.index_cb2.isChecked():
                    symbol_list = [self.status["ltp_symbol"]]
                    self.helper.get_data_downloader(symbol_list,self.interval_cb)

            if self.above_cb.isChecked() or self.below_cb.isChecked() or self.close_cb.isChecked():
                self.break_out_thread()

            else:
                self.helper.index_ord(self.strike_le2,self.name_cb,self.quantity_le,self.lot_le,self.df,self,self.status,self.ltp_data,self.percent_cb,self.point_cb,self.percent_cb2,self.point_cb2,self.target_le,self.stoploss_le,self.index_cb3,self.strike_cb2,self.index_cb4,self.strike_cb3,self.limit_cb,self.stoploss_cb,self.target_cb,self.lot_cb,self.market_cb,self.lvl_price_cb,self.abo_bolw_input_le,self.avg_price_cb,self.order_data,self.buy_cb,self.sell_cb,self.same_strike_cb,self.ce_cb2,self.pe_cb2,self.ce_cb,self.pe_cb,self.index_cb2,self.strike_cb)

    #     if self.future_cb.isChecked():
    #         if self.buy_cb.isChecked():

    #             self.helper.future_ord(1,self.name_cb,self.quantity_le,self.lot_le,self.df,self,self.status,self.ltp_data,self.percent_cb,self.point_cb,self.percent_cb2,self.point_cb2,self.target_le,self.stoploss_le,self.lot_cb)
    #         if self.sell_cb.isChecked():
    #             self.helper.future_ord(-1,self.name_cb,self.quantity_le,self.lot_le,self.df,self,self.status,self.ltp_data,self.percent_cb,self.point_cb,self.percent_cb2,self.point_cb2,self.target_le,self.stoploss_le,self.lot_cb)

        else:
            QMessageBox.critical(self, "Input Error", "Please ensure all inputs are filled correctly.")

    def place_order_litemode(self):
        if self.index_checkbox.isChecked() :
            if self.ce_checkbox.isChecked() and self.buy_checkbox.isChecked():
                self.helper.index_ord("CE",1,self.strike_line_edit,self.name_combo_box,self.quantity_checkbox,self.lot_line_edit,self.df,self)
            if self.ce_checkbox.isChecked() and self.sell_checkbox.isChecked():
                self.helper.index_ord("CE",-1,self.strike_line_edit,self.name_combo_box,self.quantity_checkbox,self.lot_line_edit,self.df,self)
            if self.pe_checkbox.isChecked() and self.buy_checkbox.isChecked():
                self.helper.index_ord("PE",1,self.strike_line_edit,self.name_combo_box,self.quantity_checkbox,self.lot_line_edit,self.df,self)
            if self.pe_checkbox.isChecked() and self.sell_checkbox.isChecked():
                self.helper.index_ord("PE",-1,self.strike_line_edit,self.name_combo_box,self.quantity_checkbox,self.lot_line_edit,self.df,self)

        if self.future_checkbox.isChecked():
            if self.buy_checkbox.isChecked():
                self.helper.future_ord(1,self.name_combo_box,self.quantity_checkbox,self.lot_line_edit,self.df,self)
            if self.sell_checkbox.isChecked():
                self.helper.future_ord(-1,self.name_combo_box,self.quantity_checkbox,self.lot_line_edit,self.df,self)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindows()
    window.show()
    sys.exit(app.exec())
