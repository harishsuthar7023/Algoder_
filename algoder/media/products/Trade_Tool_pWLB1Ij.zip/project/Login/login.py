
from fyers_apiv3 import fyersModel
import json
from urllib.parse import parse_qs,urlparse
import sys,os,pyotp
import requests as rq
from time import sleep, time
import datetime as dt


def login(apps_id,secret_keys,fyr_id, totps,pin):
    today = str(dt.date.today())
    file_name = f"access_token{today}.txt"
    file_path = os.path.join("utils", file_name)
    if not os.path.exists(file_path):
        APP_ID = apps_id
        APP_TYPE = "100"
        SECRET_KEY = secret_keys
        client_id = f"{APP_ID}-{APP_TYPE}"

        FY_ID = fyr_id
        APP_ID_TYPE = "2"
        TOTP_KEY = totps
        PIN = pin

        REDIRECT_URI = "https://www.google.com/"
        BASE_URL = "https://api-t2.fyers.in/vagator/v2"
        BASE_URL_2 = "https://api.fyers.in/api/v2"
        URL_SEND_LOGIN_OTP = BASE_URL + "/send_login_otp"
        URL_VERIFY_TOTP = BASE_URL + "/verify_otp"
        URL_VERIFY_PIN = BASE_URL + "/verify_pin"
        URL_TOKEN = BASE_URL_2 + "/token"
        URL_VALIDATE_AUTH_CODE = BASE_URL_2 + "/validate-authcode"
        SUCCESS = 1
        ERROR = -1

        def send_login_otp(fy_id, app_id):
            try:
                result_string = rq.post(url=URL_SEND_LOGIN_OTP, json= {"fy_id": fy_id, "app_id": app_id })
                if result_string.status_code != 200:
                    return [ERROR, result_string.text]
                result = json.loads(result_string.text)
                request_key = result["request_key"]
                return [SUCCESS, request_key]
            except Exception as e:
                return [ERROR, e]

        def verify_totp(request_key, totp):
            try:
                result_string = rq.post(url=URL_VERIFY_TOTP, json={"request_key": request_key,"otp": totp})
                if result_string.status_code != 200:
                    return [ERROR, result_string.text]
                result = json.loads(result_string.text)
                request_key = result["request_key"]
                return [SUCCESS, request_key]
            except Exception as e:
                return [ERROR, e]

        session = fyersModel.SessionModel(client_id=client_id, secret_key=SECRET_KEY, redirect_uri=REDIRECT_URI,
                                    response_type='code', grant_type='authorization_code')
        urlToActivate = session.generate_authcode()
        # print(urlToActivate)
        # sys.exit()
        send_otp_result = send_login_otp(fy_id=FY_ID, app_id=APP_ID_TYPE)

        if send_otp_result[0] != SUCCESS:
            print(f"send_login_otp failure - {send_otp_result[1]}")
            sys.exit()
        else:
            print("send_login_otp success")

        for i in range(1,3):
            request_key = send_otp_result[1]
            verify_totp_result = verify_totp(request_key=request_key, totp=pyotp.TOTP(TOTP_KEY).now())
            if verify_totp_result[0] != SUCCESS:
                print(f"verify_totp_result failure - {verify_totp_result[1]}")
                time.sleep(1)
            else:
                print(f"verify_totp_result success")
                break

        request_key_2 = verify_totp_result[1]
        ses = rq.Session()
        payload_pin = {"request_key":f"{request_key_2}","identity_type":"pin","identifier":f"{PIN}","recaptcha_token":""}
        res_pin = ses.post('https://api-t2.fyers.in/vagator/v2/verify_pin', json=payload_pin).json()
        ses.headers.update({
            'authorization': f"Bearer {res_pin['data']['access_token']}"})

        authParam = {"fyers_id":FY_ID,"app_id":APP_ID,"redirect_uri":REDIRECT_URI,"appType":APP_TYPE,"code_challenge":"","state":"None","scope":"","nonce":"","response_type":"code","create_cookie":True}
        authres = ses.post('https://api.fyers.in/api/v2/token', json=authParam).json()

        url = authres['Url']

        parsed = urlparse(url)
        auth_code = parse_qs(parsed.query)['auth_code'][0]

        session.set_token(auth_code)
        response = session.generate_token()
        access_token= response["access_token"]

        today = str(dt.date.today())
        folder_path = 'utils'

            # Folder ke saari files ko list karein
        for filename in os.listdir(folder_path):
            # Check karein agar filename 'data' se start hoti hai
            if filename.startswith('access') and filename.endswith('.txt'):
                file_path = os.path.join(folder_path, filename)
                # File ko remove karen
                os.remove(file_path)

        with open(f"utils/access_token{today}.txt","w") as file:
            file.write(access_token)

        fyers = fyersModel.FyersModel(client_id=client_id, token=access_token, log_path='utils/')
        print(f"Welcome .. {fyers.get_profile()['data']['name']} .. ")
        print("Login Successfully")
    else:
        print("already login")


